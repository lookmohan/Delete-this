# Pratheep Raj A & Vaishnavi R — South Indian Wedding Invitation Website

A multi-page, bilingual (English & Tamil) digital South Indian wedding invitation built with React, Vite, React Router DOM, Tailwind CSS, Framer Motion, and Lucide React.

---

## Pages & Routes

| Page | Route |
|---|---|
| Home | `/` |
| Invitation | `/invitation` |
| Couple | `/couple` |
| Events | `/events` |
| Countdown | `/countdown` |
| Gallery | `/gallery` |
| Send Wishes | `/wishes` |

---

## 1. Installation & Running Locally

Install dependencies:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

Build for production:

```bash
npm run build
```

Preview the production build locally:

```bash
npm run preview
```

---

## 2. Replacing the Couple Photograph

1. Place your photograph at:
   ```text
   public/images/couple.jpg
   ```
2. No component edits are required. Until `couple.jpg` is added, an ornamental kolam monogram frame is displayed automatically without broken image icons.
3. To change the filename or path, update `images.couple` in `src/data/weddingConfig.js`.

---

## 3. Adding Gallery Photographs

1. Place your wedding photos inside:
   ```text
   public/images/gallery/
   ```
2. Open `src/data/gallery.js` and add or update entries with `src: "/images/gallery/your-photo.jpg"` along with English and Tamil captions and alt text.

---

## 4. Replacing the Wedding Music

1. Place your audio track at:
   ```text
   public/audio/wedding-song.mp3
   ```
2. Playback never autoplays; visitors start or pause music using the floating music player button, and playback persists seamlessly across all seven routes.
3. To change the audio path, update `audio` in `src/data/weddingConfig.js`.

---

## 5. Updating Event Timings & Venue Details

All wedding details are stored centrally in `src/data/weddingConfig.js`.

- **Timings**: When a ceremony timing is confirmed, set `time` in 24-hour format (e.g. `"09:30"`) and set `timeConfirmed: true`.
- **Countdown**: Update `countdown.date` and `countdown.time` in `src/data/weddingConfig.js`. Until `countdown.time` is confirmed, the countdown tracks the start of April 23, 2027 (`00:00` in `Asia/Kolkata`).
- **Venues & Maps**: Update `venue`, `mapUrl`, `directionsUrl`, or `openMapUrl` inside `weddingConfig.events`.

---

## 6. Configuring the Family WhatsApp Number

1. Open `src/data/weddingConfig.js`.
2. Set `whatsappNumber` using digits only with country code (for example, `"919876543210"`).
3. When `whatsappNumber` is empty, the **Send Your Blessings** page automatically uses the native Web Share API when supported, or copies the invitation link and blessing text to the clipboard.

---

## 7. Editing English & Tamil Content

All UI copy, headings, invitation paragraphs, event labels, and button labels for both English (`en`) and Tamil (`ta`) are stored in:

```text
src/data/translations.js
```

---

## 8. Deploying the Website

1. Run `npm run build` to generate the static bundle in `dist/`.
2. Deploy the `dist/` directory to any static host (Vercel, Netlify, Cloudflare Pages, Firebase Hosting, or GitHub Pages).
3. Configure your host to rewrite all routes (e.g. `/invitation`, `/events`, `/wishes`) to `index.html` so direct route URLs load properly.
