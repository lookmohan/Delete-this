import { useEffect, useState } from "react";
import {
  BrowserRouter,
  Route,
  Routes,
  useLocation,
  Navigate,
} from "react-router-dom";
import { AnimatePresence, MotionConfig } from "framer-motion";
import { LanguageProvider } from "./context/LanguageContext";
import { MusicProvider } from "./context/MusicContext";
import { IntroLoader } from "./components/IntroLoader";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { MusicPlayer } from "./components/MusicPlayer";
import { MobileActionBar } from "./components/MobileActionBar";
import Home from "./pages/Home";
import Invitation from "./pages/Invitation";
import Couple from "./pages/Couple";
import Events from "./pages/Events";
import Countdown from "./pages/Countdown";
import Gallery from "./pages/Gallery";
import Wishes from "./pages/Wishes";

const INTRO_SESSION_KEY = "pv_wedding_intro_completed";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [pathname]);
  return null;
}

function AppShell() {
  const location = useLocation();
  const [showIntro, setShowIntro] = useState(() => {
    try {
      return window.sessionStorage.getItem(INTRO_SESSION_KEY) !== "true";
    } catch {
      return true;
    }
  });

  const handleIntroComplete = () => {
    try {
      window.sessionStorage.setItem(INTRO_SESSION_KEY, "true");
    } catch {
      // Ignore storage errors
    }
    setShowIntro(false);
  };

  const handleReplayIntro = () => {
    setShowIntro(true);
  };

  return (
    <div className="flex min-h-dvh flex-col bg-[#FFF0E8] text-[#351B29]">
      <ScrollToTop />

      <AnimatePresence mode="wait">
        {showIntro && <IntroLoader key="intro-loader" onComplete={handleIntroComplete} />}
      </AnimatePresence>

      {!showIntro && (
        <>
          <Navbar />

          <main className="flex-1">
            <AnimatePresence mode="wait">
              <Routes location={location} key={location.pathname}>
                <Route path="/" element={<Home />} />
                <Route path="/invitation" element={<Invitation />} />
                <Route path="/couple" element={<Couple />} />
                <Route path="/events" element={<Events />} />
                <Route path="/countdown" element={<Countdown />} />
                <Route path="/gallery" element={<Gallery />} />
                <Route path="/wishes" element={<Wishes />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AnimatePresence>
          </main>

          <Footer onReplayIntro={handleReplayIntro} />
          <MusicPlayer />
          <MobileActionBar />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <LanguageProvider>
        <MusicProvider>
          <BrowserRouter>
            <AppShell />
          </BrowserRouter>
        </MusicProvider>
      </LanguageProvider>
    </MotionConfig>
  );
}
