export const EASE_LUXURY = [0.22, 1, 0.36, 1];

export const pageTransitionVariants = {
  initial: {
    opacity: 0,
    y: 14,
    scale: 0.992,
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.45,
      ease: EASE_LUXURY,
    },
  },
  exit: {
    opacity: 0,
    y: -10,
    scale: 0.994,
    transition: {
      duration: 0.28,
      ease: EASE_LUXURY,
    },
  },
};

export const staggerContainer = {
  hidden: { opacity: 0 },
  visible: (stagger = 0.09) => ({
    opacity: 1,
    transition: {
      staggerChildren: stagger,
      delayChildren: 0.08,
    },
  }),
};

export const fadeUpItem = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.65,
      ease: EASE_LUXURY,
    },
  },
};

export const clipRevealImage = {
  hidden: {
    clipPath: "inset(10% 6% 10% 6% round 12px)",
    opacity: 0,
    scale: 1.07,
  },
  visible: {
    clipPath: "inset(0% 0% 0% 0% round 12px)",
    opacity: 1,
    scale: 1,
    transition: {
      duration: 1.05,
      ease: EASE_LUXURY,
    },
  },
};

export const dividerDraw = {
  hidden: { scaleX: 0, opacity: 0 },
  visible: {
    scaleX: 1,
    opacity: 1,
    transition: {
      duration: 0.85,
      ease: EASE_LUXURY,
    },
  },
};

export const kolamStrokeVariant = {
  hidden: { pathLength: 0, opacity: 0 },
  visible: (delay = 0) => ({
    pathLength: 1,
    opacity: 1,
    transition: {
      pathLength: { duration: 1.4, delay, ease: EASE_LUXURY },
      opacity: { duration: 0.4, delay },
    },
  }),
};
