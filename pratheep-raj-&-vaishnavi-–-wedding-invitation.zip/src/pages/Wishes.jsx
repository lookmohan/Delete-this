import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { KolamMandala, TempleDivider } from "../components/OrnamentalMotifs";
import { BlessingsButton } from "../components/BlessingsButton";

export default function Wishes() {
  const { t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const [senderName, setSenderName] = useState("");
  const [message, setMessage] = useState("");

  return (
    <PageTransition>
      <section className="kolam-surface-pattern px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="mx-auto max-w-3xl">
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE_LUXURY }}
            className="rounded-2xl border border-[#B66A54]/30 bg-[#FFF0E8] p-6 shadow-sm sm:p-10 lg:p-12"
          >
            <div className="text-center">
              <div className="flex justify-center">
                <KolamMandala className="mb-4 h-20 w-20" animated />
              </div>

              <p className="text-xs font-semibold tracking-[0.22em] text-[#B66A54] uppercase">
                {t.wishes.kicker}
              </p>

              <h1 className="text-balance mt-2 font-serif text-3xl font-semibold text-[#762C3A] sm:text-5xl">
                {t.wishes.heading}
              </h1>

              <p className="mt-3 font-serif text-lg text-[#351B29]/85 sm:text-xl">
                {weddingConfig.groom.name} &amp; {weddingConfig.bride.name}
              </p>
            </div>

            <TempleDivider className="my-7" />

            <div className="mx-auto max-w-2xl space-y-4 text-center text-base leading-relaxed text-[#351B29]/90 sm:text-lg">
              {t.wishes.paragraphs.map((paragraph, idx) => (
                <motion.p
                  key={idx}
                  initial={prefersReducedMotion ? false : { opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.6,
                    delay: prefersReducedMotion ? 0 : 0.15 + idx * 0.1,
                    ease: EASE_LUXURY,
                  }}
                >
                  {paragraph}
                </motion.p>
              ))}
            </div>

            {/* Optional Personal Message Composer */}
            <div className="mx-auto mt-9 max-w-xl space-y-5 border-t border-[#B66A54]/20 pt-8">
              <div>
                <label
                  htmlFor="wishes-sender-name"
                  className="block text-sm font-medium text-[#351B29]"
                >
                  {t.wishes.senderNameLabel}
                </label>
                <input
                  id="wishes-sender-name"
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder={t.wishes.senderNamePlaceholder}
                  className="mt-2 min-h-[44px] w-full rounded-xl border border-[#B66A54]/35 bg-[#FFF0E8] px-4 py-2.5 text-base text-[#351B29] placeholder:text-[#351B29]/45 focus:border-[#762C3A] focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="wishes-message"
                  className="block text-sm font-medium text-[#351B29]"
                >
                  {t.wishes.messageLabel}
                </label>
                <textarea
                  id="wishes-message"
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={t.wishes.messagePlaceholder}
                  className="mt-2 w-full rounded-xl border border-[#B66A54]/35 bg-[#FFF0E8] px-4 py-3 text-base text-[#351B29] placeholder:text-[#351B29]/45 focus:border-[#762C3A] focus:outline-none"
                />
              </div>

              <div className="pt-3">
                <BlessingsButton senderName={senderName} customMessage={message} />
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PageTransition>
  );
}
