import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { CouplePortraitFrame } from "../components/CouplePortraitFrame";
import { KolamMandala, TempleDivider } from "../components/OrnamentalMotifs";

export default function Couple() {
  const { t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();

  return (
    <PageTransition>
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        {/* Page Header */}
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE_LUXURY }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-semibold tracking-[0.22em] text-[#B66A54] uppercase">
            {t.couple.kicker}
          </p>
          <h1 className="text-balance mt-2 font-serif text-4xl font-semibold text-[#351B29] sm:text-5xl">
            {t.couple.title}
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[#351B29]/80 sm:text-lg">
            {t.couple.subtitle}
          </p>
        </motion.div>

        <TempleDivider className="my-10" />

        {/* Couple Showcase Layout */}
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Large Couple Portrait */}
          <div className="mx-auto w-full max-w-lg lg:col-span-6 lg:max-w-none">
            <CouplePortraitFrame
              aspectClass="aspect-[4/5]"
              altText={`${weddingConfig.groom.name} & ${weddingConfig.bride.name}`}
              placeholderNote={t.couple.photoNote}
            />
          </div>

          {/* Groom & Bride Parent Details */}
          <div className="space-y-8 lg:col-span-6">
            {/* Groom */}
            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.65, ease: EASE_LUXURY }}
              className="rounded-2xl border border-[#B66A54]/30 bg-[#FFF0E8] p-6 sm:p-8"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                  {t.couple.groomTitle}
                </span>
                <KolamMandala className="h-8 w-8 opacity-75" />
              </div>

              <h2 className="mt-2 font-serif text-3xl font-semibold text-[#762C3A] sm:text-4xl">
                {weddingConfig.groom.name}
              </h2>

              <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-[#B66A54]/20 pt-5">
                <div>
                  <dt className="text-xs font-medium tracking-wider text-[#351B29]/65 uppercase">
                    {t.couple.fatherLabel}
                  </dt>
                  <dd className="mt-1 font-serif text-xl font-medium text-[#351B29]">
                    {weddingConfig.groom.father}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-medium tracking-wider text-[#351B29]/65 uppercase">
                    {t.couple.motherLabel}
                  </dt>
                  <dd className="mt-1 font-serif text-xl font-medium text-[#351B29]">
                    {weddingConfig.groom.mother}
                  </dd>
                </div>
              </dl>
            </motion.div>

            {/* Bride */}
            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.65, delay: 0.1, ease: EASE_LUXURY }}
              className="rounded-2xl border border-[#B66A54]/30 bg-[#FFF0E8] p-6 sm:p-8"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                  {t.couple.brideTitle}
                </span>
                <KolamMandala className="h-8 w-8 opacity-75" />
              </div>

              <h2 className="mt-2 font-serif text-3xl font-semibold text-[#762C3A] sm:text-4xl">
                {weddingConfig.bride.name}
              </h2>

              <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-[#B66A54]/20 pt-5">
                <div>
                  <dt className="text-xs font-medium tracking-wider text-[#351B29]/65 uppercase">
                    {t.couple.fatherLabel}
                  </dt>
                  <dd className="mt-1 font-serif text-xl font-medium text-[#351B29]">
                    {weddingConfig.bride.father}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-medium tracking-wider text-[#351B29]/65 uppercase">
                    {t.couple.motherLabel}
                  </dt>
                  <dd className="mt-1 font-serif text-xl font-medium text-[#351B29]">
                    {weddingConfig.bride.mother}
                  </dd>
                </div>
              </dl>
            </motion.div>

            {/* Navigation Actions */}
            <div className="flex flex-col gap-3 pt-2 sm:flex-row">
              <Link
                to="/invitation"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#762C3A] px-6 py-3 text-sm font-semibold text-[#FFF0E8] transition-all hover:scale-[1.02] hover:bg-[#8B3545]"
              >
                <span>{t.couple.invitationCta}</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/events"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-[#762C3A]/35 px-6 py-3 text-sm font-semibold text-[#762C3A] transition-colors hover:border-[#762C3A] hover:bg-[#762C3A]/5"
              >
                <span>{t.couple.eventsCta}</span>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
}
