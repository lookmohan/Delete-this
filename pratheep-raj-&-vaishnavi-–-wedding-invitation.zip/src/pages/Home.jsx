import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, CalendarDays, Clock, MapPin } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import {
  formatEventDate,
  formatTimeDisplay,
  weddingEventsList,
} from "../data/events";
import { galleryPhotos } from "../data/gallery";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { CouplePortraitFrame } from "../components/CouplePortraitFrame";
import {
  JasminePetalsLayer,
  KolamMandala,
  TempleDivider,
} from "../components/OrnamentalMotifs";
import { CountdownTimer } from "../components/CountdownTimer";
import { GalleryCard } from "../components/GalleryGrid";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const navigate = useNavigate();

  return (
    <PageTransition>
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="kolam-surface-pattern relative overflow-hidden border-b border-[#B66A54]/20 bg-[#FFF0E8]">
        <JasminePetalsLayer count={7} light={false} />

        <div className="relative z-10 mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
          <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
            {/* Hero Copy Column */}
            <div className="order-2 text-center lg:order-1 lg:col-span-7 lg:text-left">
              <motion.p
                initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.65, delay: 0.1, ease: EASE_LUXURY }}
                className="text-xs font-semibold tracking-[0.22em] text-[#762C3A] uppercase sm:text-sm"
              >
                {t.home.kicker}
              </motion.p>

              <motion.h1
                initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.22, ease: EASE_LUXURY }}
                className="text-balance mt-4 font-serif text-4xl leading-[1.12] font-semibold tracking-tight text-[#351B29] sm:text-5xl lg:text-6xl xl:text-7xl"
              >
                <span>{weddingConfig.groom.name}</span>
                <span className="mx-3 font-normal italic text-[#B66A54]">&amp;</span>
                <span>{weddingConfig.bride.name}</span>
              </motion.h1>

              <motion.div
                initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.36, ease: EASE_LUXURY }}
                className="mt-5 flex flex-wrap items-center justify-center gap-3 text-sm font-medium tracking-[0.16em] text-[#762C3A] uppercase lg:justify-start"
              >
                <span>{t.weddingDateMain}</span>
                <span aria-hidden="true" className="text-[#B66A54]">
                  ·
                </span>
                <span>{t.weddingLabel}</span>
              </motion.div>

              <motion.p
                initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.48, ease: EASE_LUXURY }}
                className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-[#351B29]/85 sm:text-lg lg:mx-0"
              >
                {t.home.introLead}
              </motion.p>

              <motion.div
                initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.6, ease: EASE_LUXURY }}
                className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center lg:justify-start"
              >
                <Link
                  to="/invitation"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#762C3A] px-7 py-3 text-sm font-semibold text-[#FFF0E8] shadow-sm transition-all hover:scale-[1.02] hover:bg-[#8B3545] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] sm:text-base"
                >
                  <span>{t.home.exploreInvitation}</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>

                <Link
                  to="/events"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-[#762C3A]/40 bg-transparent px-7 py-3 text-sm font-semibold text-[#762C3A] transition-colors hover:border-[#762C3A] hover:bg-[#762C3A]/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] sm:text-base"
                >
                  <span>{t.home.exploreEvents}</span>
                </Link>
              </motion.div>
            </div>

            {/* Hero Portrait Column */}
            <div className="order-1 mx-auto w-full max-w-md lg:order-2 lg:col-span-5 lg:max-w-none">
              <CouplePortraitFrame
                priority
                aspectClass="aspect-[4/5]"
                altText={`${weddingConfig.groom.name} & ${weddingConfig.bride.name}`}
                placeholderNote={t.couple.photoNote}
              />
            </div>
          </div>
        </div>
      </section>

      {/* 2. FAMILY INTRODUCTION */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.7, ease: EASE_LUXURY }}
          className="text-center"
        >
          <p className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
            {t.home.familySubheading}
          </p>
          <h2 className="text-balance mt-2 font-serif text-3xl font-semibold text-[#351B29] sm:text-4xl">
            {t.home.familyHeading}
          </h2>
          <TempleDivider className="my-7" />
        </motion.div>

        <div className="mt-8 grid gap-8 md:grid-cols-2 md:gap-12">
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.65, ease: EASE_LUXURY }}
            className="rounded-2xl border border-[#B66A54]/25 bg-[#FFF0E8] p-7 text-center sm:p-9"
          >
            <p className="text-xs font-semibold tracking-[0.18em] text-[#B66A54] uppercase">
              {t.home.groomSide}
            </p>
            <h3 className="mt-3 font-serif text-2xl font-semibold text-[#762C3A] sm:text-3xl">
              {weddingConfig.groom.name}
            </h3>
            <p className="mt-3 text-sm text-[#351B29]/75">{t.home.sonOf}</p>
            <p className="mt-1 font-serif text-xl font-medium text-[#351B29]">
              {weddingConfig.groom.father} &amp; {weddingConfig.groom.mother}
            </p>
          </motion.div>

          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.65, delay: 0.1, ease: EASE_LUXURY }}
            className="rounded-2xl border border-[#B66A54]/25 bg-[#FFF0E8] p-7 text-center sm:p-9"
          >
            <p className="text-xs font-semibold tracking-[0.18em] text-[#B66A54] uppercase">
              {t.home.brideSide}
            </p>
            <h3 className="mt-3 font-serif text-2xl font-semibold text-[#762C3A] sm:text-3xl">
              {weddingConfig.bride.name}
            </h3>
            <p className="mt-3 text-sm text-[#351B29]/75">{t.home.daughterOf}</p>
            <p className="mt-1 font-serif text-xl font-medium text-[#351B29]">
              {weddingConfig.bride.father} &amp; {weddingConfig.bride.mother}
            </p>
          </motion.div>
        </div>
      </section>

      {/* 3. WEDDING EVENT HIGHLIGHTS */}
      <section className="border-y border-[#B66A54]/20 bg-[#E9BFA5]/15 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                {t.home.eventsSubheading}
              </p>
              <h2 className="mt-2 font-serif text-3xl font-semibold text-[#351B29] sm:text-4xl">
                {t.home.eventsHeading}
              </h2>
            </div>

            <Link
              to="/events"
              className="inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-[#762C3A] transition-colors hover:text-[#351B29]"
            >
              <span>{t.home.viewAllEvents}</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {weddingEventsList.map((event, idx) => (
              <motion.div
                key={event.id}
                initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.6, delay: idx * 0.08, ease: EASE_LUXURY }}
                className="flex flex-col justify-between rounded-xl border border-[#B66A54]/25 bg-[#FFF0E8] p-6 sm:p-7"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-semibold tracking-[0.18em] text-[#B66A54] uppercase">
                    <span>{event.order}</span>
                    <span>{language === "ta" ? event.title.en : event.title.ta}</span>
                  </div>

                  <h3 className="mt-3 font-serif text-2xl font-semibold text-[#351B29]">
                    {event.title[language]}
                  </h3>

                  <div className="mt-5 space-y-2.5 border-t border-[#B66A54]/20 pt-4 text-sm text-[#351B29]/85">
                    <div className="flex items-center gap-2.5">
                      <CalendarDays className="h-4 w-4 shrink-0 text-[#B66A54]" />
                      <span>{formatEventDate(event.date, language)}</span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <Clock className="h-4 w-4 shrink-0 text-[#B66A54]" />
                      <span className={event.timeConfirmed ? "font-medium" : "italic"}>
                        {formatTimeDisplay(event.time, event.timeConfirmed, language)}
                      </span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#B66A54]" />
                      <span className={event.venue ? "font-medium" : "italic"}>
                        {event.venue || t.events.venuePending}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-2">
                  <Link
                    to="/events"
                    className="inline-flex min-h-[40px] items-center gap-1.5 text-sm font-semibold text-[#762C3A] transition-colors hover:text-[#351B29]"
                  >
                    <span>{t.events.getDirections}</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. COUNTDOWN PREVIEW */}
      <section className="kolam-dark-pattern bg-[#351B29] py-16 text-[#FFF0E8] sm:py-20">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-xs font-semibold tracking-[0.2em] text-[#E9BFA5] uppercase">
            {t.weddingDateMain}
          </p>
          <h2 className="text-balance mt-2 font-serif text-3xl font-semibold text-[#FFF0E8] sm:text-4xl">
            {t.home.countdownHeading}
          </h2>

          <div className="mt-9">
            <CountdownTimer compact dark />
          </div>

          <div className="mt-9">
            <Link
              to="/countdown"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#E9BFA5]/40 px-6 py-2.5 text-sm font-semibold text-[#E9BFA5] transition-colors hover:border-[#FFF0E8] hover:text-[#FFF0E8]"
            >
              <span>{t.home.countdownLink}</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 5. GALLERY PREVIEW */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
              {t.home.gallerySubheading}
            </p>
            <h2 className="mt-2 font-serif text-3xl font-semibold text-[#351B29] sm:text-4xl">
              {t.home.galleryHeading}
            </h2>
          </div>

          <Link
            to="/gallery"
            className="inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-[#762C3A] transition-colors hover:text-[#351B29]"
          >
            <span>{t.home.viewGallery}</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {galleryPhotos.slice(0, 3).map((item, idx) => (
            <GalleryCard
              key={item.id}
              item={item}
              index={idx}
              onOpen={() => navigate("/gallery")}
            />
          ))}
        </div>
      </section>

      {/* 6. SEND WISHES CALL-TO-ACTION */}
      <section className="border-t border-[#B66A54]/20 bg-[#E9BFA5]/20 py-16 sm:py-20">
        <div className="mx-auto flex max-w-3xl flex-col items-center px-4 text-center sm:px-6">
          <KolamMandala className="mb-5 h-16 w-16 opacity-80" />
          <h2 className="text-balance font-serif text-3xl font-semibold text-[#351B29] sm:text-4xl">
            {t.home.wishesHeading}
          </h2>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-[#351B29]/85">
            {t.home.wishesBody}
          </p>
          <Link
            to="/wishes"
            className="mt-8 inline-flex min-h-[48px] items-center gap-2.5 rounded-xl bg-[#762C3A] px-8 py-3.5 text-base font-semibold text-[#FFF0E8] shadow-sm transition-all hover:scale-[1.02] hover:bg-[#8B3545] active:scale-[0.98]"
          >
            <span>{t.home.sendWishesCta}</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </PageTransition>
  );
}
