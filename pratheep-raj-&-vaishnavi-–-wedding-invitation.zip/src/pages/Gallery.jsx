import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ImagePlus } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { galleryPhotos } from "../data/gallery";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { TempleDivider } from "../components/OrnamentalMotifs";
import { GalleryGrid } from "../components/GalleryGrid";
import { Lightbox } from "../components/Lightbox";

export default function Gallery() {
  const { t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const [activeIndex, setActiveIndex] = useState(null);

  const hasCustomPhotos = galleryPhotos.some(
    (item) => item.src && item.src.trim() !== ""
  );

  return (
    <PageTransition>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE_LUXURY }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-semibold tracking-[0.22em] text-[#B66A54] uppercase">
            {t.gallery.kicker}
          </p>
          <h1 className="text-balance mt-2 font-serif text-4xl font-semibold text-[#351B29] sm:text-5xl">
            {t.gallery.title}
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[#351B29]/80 sm:text-lg">
            {t.gallery.subtitle}
          </p>
        </motion.div>

        <TempleDivider className="my-10" />

        {!hasCustomPhotos && (
          <div className="mb-10 flex items-start gap-3 rounded-xl border border-[#B66A54]/30 bg-[#E9BFA5]/20 p-4 text-sm leading-relaxed text-[#351B29] sm:p-5">
            <ImagePlus className="mt-0.5 h-5 w-5 shrink-0 text-[#762C3A]" />
            <div>
              <p className="font-semibold text-[#762C3A]">
                {t.gallery.emptyNoticeTitle}
              </p>
              <p className="mt-1 text-[#351B29]/85">{t.gallery.emptyNoticeBody}</p>
            </div>
          </div>
        )}

        <GalleryGrid
          items={galleryPhotos}
          onSelect={(index) => setActiveIndex(index)}
        />
      </section>

      <Lightbox
        items={galleryPhotos}
        activeIndex={activeIndex}
        onClose={() => setActiveIndex(null)}
        onNavigate={(nextIndex) => setActiveIndex(nextIndex)}
      />
    </PageTransition>
  );
}
