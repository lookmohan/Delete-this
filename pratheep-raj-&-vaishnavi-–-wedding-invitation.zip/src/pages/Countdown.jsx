import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Info } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { formatEventDate } from "../data/events";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { CountdownTimer } from "../components/CountdownTimer";
import {
  JasminePetalsLayer,
  KolamMandala,
  TempleDivider,
} from "../components/OrnamentalMotifs";

export default function Countdown() {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();

  const formattedWeddingDate = formatEventDate(
    weddingConfig.countdown.date,
    language
  );
  const timeConfirmed =
    weddingConfig.countdown.time && weddingConfig.countdown.time.trim() !== "";

  return (
    <PageTransition>
      <section className="kolam-dark-pattern relative flex min-h-[calc(100dvh-8rem)] flex-col items-center justify-center overflow-hidden bg-[#351B29] px-4 py-14 text-[#FFF0E8] sm:px-6 sm:py-20 lg:px-8">
        <JasminePetalsLayer count={8} light />

        <div className="relative z-10 mx-auto w-full max-w-4xl text-center">
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, ease: EASE_LUXURY }}
            className="flex flex-col items-center"
          >
            <KolamMandala className="mb-5 h-20 w-20 sm:h-24 sm:w-24" animated light />

            <p className="text-xs font-semibold tracking-[0.22em] text-[#E9BFA5] uppercase sm:text-sm">
              {t.countdown.kicker}
            </p>

            <h1 className="text-balance mt-3 font-serif text-4xl font-semibold text-[#FFF0E8] sm:text-5xl lg:text-6xl">
              {t.countdown.title}
            </h1>

            <p className="mt-4 font-serif text-2xl text-[#E9BFA5] sm:text-3xl">
              {weddingConfig.groom.name} &amp; {weddingConfig.bride.name}
            </p>

            <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-sm text-[#E9BFA5]/80">
              <span>{formattedWeddingDate}</span>
              <span aria-hidden="true">·</span>
              <span>{t.countdown.timezoneLabel}</span>
            </div>
          </motion.div>

          <TempleDivider className="my-9" light />

          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.15, ease: EASE_LUXURY }}
          >
            <CountdownTimer dark />
          </motion.div>

          {/* Honest timing convention explanation when ceremony time is not yet confirmed */}
          {!timeConfirmed && (
            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.65, delay: 0.3 }}
              className="mx-auto mt-8 flex max-w-2xl items-start gap-3 rounded-xl border border-[#E9BFA5]/25 bg-[#FFF0E8]/5 p-4 text-left text-xs leading-relaxed text-[#E9BFA5]/90 sm:text-sm"
            >
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#E9BFA5]" />
              <p>{t.countdown.timeConventionNote}</p>
            </motion.div>
          )}

          <div className="mt-10 flex justify-center">
            <Link
              to="/events"
              className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-[#762C3A] px-7 py-3 text-sm font-semibold text-[#FFF0E8] transition-all hover:scale-[1.02] hover:bg-[#8B3545] sm:text-base"
            >
              <span>{t.countdown.exploreEvents}</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </PageTransition>
  );
}
