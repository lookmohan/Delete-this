import { motion, useReducedMotion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { TempleDivider } from "../components/OrnamentalMotifs";
import { EventTimeline } from "../components/EventTimeline";

export default function Events() {
  const { t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();

  return (
    <PageTransition>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE_LUXURY }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-semibold tracking-[0.22em] text-[#B66A54] uppercase">
            {t.events.kicker}
          </p>
          <h1 className="text-balance mt-2 font-serif text-4xl font-semibold text-[#351B29] sm:text-5xl">
            {t.events.title}
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[#351B29]/80 sm:text-lg">
            {t.events.subtitle}
          </p>
        </motion.div>

        <TempleDivider className="my-10 sm:my-12" />

        <EventTimeline />
      </section>
    </PageTransition>
  );
}
