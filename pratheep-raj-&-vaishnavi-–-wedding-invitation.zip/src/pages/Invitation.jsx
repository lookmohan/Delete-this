import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import {
  formatEventDate,
  formatTimeDisplay,
  weddingEventsList,
} from "../data/events";
import { EASE_LUXURY } from "../animations/motionVariants";
import { PageTransition } from "../components/PageTransition";
import { KolamMandala, TempleDivider } from "../components/OrnamentalMotifs";

export default function Invitation() {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();

  return (
    <PageTransition>
      <section className="kolam-surface-pattern px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="mx-auto max-w-4xl">
          {/* Traditional Digital Invitation Card */}
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, ease: EASE_LUXURY }}
            className="relative overflow-hidden rounded-2xl border border-[#B66A54]/35 bg-[#FFF0E8] p-6 shadow-sm sm:p-12 lg:p-14"
          >
            {/* Inner Ornamental Hairline Border */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-3 rounded-xl border border-[#E9BFA5]/70 sm:inset-4"
            />

            <div className="relative z-10 text-center">
              {/* Decorative Header */}
              <motion.div
                initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, ease: EASE_LUXURY }}
                className="flex flex-col items-center"
              >
                <KolamMandala className="mb-4 h-20 w-20 sm:h-24 sm:w-24" animated />
                <p className="text-xs font-semibold tracking-[0.22em] text-[#B66A54] uppercase sm:text-sm">
                  {t.invitation.kicker}
                </p>
                <h1 className="mt-2 font-serif text-3xl font-semibold text-[#762C3A] sm:text-5xl">
                  {t.invitation.title}
                </h1>
                <p className="mt-2 font-serif text-lg italic text-[#351B29]/80 sm:text-xl">
                  {t.invitation.subtitle}
                </p>
              </motion.div>

              <TempleDivider className="my-8" />

              {/* Staggered Family & Couple Introduction */}
              <div className="grid gap-8 sm:grid-cols-2 sm:gap-10">
                <motion.div
                  initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.65, delay: 0.15, ease: EASE_LUXURY }}
                  className="space-y-2"
                >
                  <p className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                    {t.invitation.groomLabel}
                  </p>
                  <h2 className="font-serif text-2xl font-semibold text-[#351B29] sm:text-3xl">
                    {weddingConfig.groom.name}
                  </h2>
                  <p className="text-sm text-[#762C3A]/85">
                    {t.invitation.parentsPrefixGroom}
                  </p>
                  <p className="font-serif text-lg font-medium text-[#351B29]">
                    {weddingConfig.groom.father} &amp; {weddingConfig.groom.mother}
                  </p>
                </motion.div>

                <motion.div
                  initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.65, delay: 0.25, ease: EASE_LUXURY }}
                  className="space-y-2"
                >
                  <p className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                    {t.invitation.brideLabel}
                  </p>
                  <h2 className="font-serif text-2xl font-semibold text-[#351B29] sm:text-3xl">
                    {weddingConfig.bride.name}
                  </h2>
                  <p className="text-sm text-[#762C3A]/85">
                    {t.invitation.parentsPrefixBride}
                  </p>
                  <p className="font-serif text-lg font-medium text-[#351B29]">
                    {weddingConfig.bride.father} &amp; {weddingConfig.bride.mother}
                  </p>
                </motion.div>
              </div>

              <TempleDivider className="my-8" />

              {/* Invitation Message Prose */}
              <div className="mx-auto max-w-2xl space-y-5 text-base leading-relaxed text-[#351B29]/90 sm:text-lg sm:leading-loose">
                {t.invitation.messageParagraphs.map((para, idx) => (
                  <motion.p
                    key={idx}
                    initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.65,
                      delay: prefersReducedMotion ? 0 : 0.3 + idx * 0.1,
                      ease: EASE_LUXURY,
                    }}
                  >
                    {para}
                  </motion.p>
                ))}
              </div>

              {/* Auspicious Wedding Date Banner */}
              <motion.div
                initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.65, ease: EASE_LUXURY }}
                className="mt-10 rounded-xl border border-[#E9BFA5]/40 bg-[#351B29] px-6 py-6 text-[#FFF0E8]"
              >
                <p className="text-xs font-semibold tracking-[0.2em] text-[#E9BFA5] uppercase">
                  {t.invitation.weddingDateTitle}
                </p>
                <p className="mt-1.5 font-serif text-2xl font-semibold text-[#FFF0E8] sm:text-3xl">
                  {formatEventDate(weddingConfig.events.wedding.date, language)}
                </p>
              </motion.div>

              {/* Ceremony Highlights List */}
              <div className="mt-10">
                <h3 className="text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                  {t.invitation.highlightsTitle}
                </h3>
                <div className="mt-5 grid gap-4 text-left sm:grid-cols-3">
                  {weddingEventsList.map((ev) => (
                    <div
                      key={ev.id}
                      className="rounded-xl border border-[#B66A54]/25 bg-[#E9BFA5]/15 p-4"
                    >
                      <p className="font-serif text-lg font-semibold text-[#762C3A]">
                        {ev.title[language]}
                      </p>
                      <p className="mt-1 text-sm font-medium text-[#351B29]">
                        {formatEventDate(ev.date, language)}
                      </p>
                      <p className="mt-0.5 text-xs text-[#351B29]/75">
                        {formatTimeDisplay(ev.time, ev.timeConfirmed, language)}
                      </p>
                      {ev.venue && (
                        <p className="mt-1.5 text-xs font-medium text-[#762C3A]">
                          {ev.venue}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="mt-10 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
                <Link
                  to="/events"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#762C3A] px-7 py-3 text-sm font-semibold text-[#FFF0E8] transition-all hover:scale-[1.02] hover:bg-[#8B3545] sm:text-base"
                >
                  <span>{t.invitation.viewEventsBtn}</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/wishes"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-[#762C3A]/35 px-7 py-3 text-sm font-semibold text-[#762C3A] transition-colors hover:border-[#762C3A] hover:bg-[#762C3A]/5 sm:text-base"
                >
                  <span>{t.invitation.sendWishesBtn}</span>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PageTransition>
  );
}
