export const weddingConfig = {
  groom: {
    name: "Pratheep Raj A",
    father: "Anbu A",
    mother: "Ammu A",
  },

  bride: {
    name: "Vaishnavi R",
    father: "Ragothaman R",
    mother: "Bharathi R",
  },

  events: {
    engagement: {
      date: "2027-02-18",
      time: "16:00",
      timeConfirmed: true,
      venue: "",
      mapUrl:
        "https://www.google.com/maps/embed?pb=!4v1795145469018!6m8!1m7!1s7yaYRjY3-GXmKh7LwVT9wQ!2m2!1d13.14297450483844!2d80.19095319354751!3f177.34202732026526!4f15.313299541335198!5f0.4000000000000002",
      directionsUrl:
        "https://www.google.com/maps/dir/?api=1&destination=13.14297450483844,80.19095319354751",
      openMapUrl:
        "https://www.google.com/maps/search/?api=1&query=13.14297450483844,80.19095319354751",
    },

    reception: {
      date: "2027-04-22",
      time: "",
      timeConfirmed: false,
      venue: "Annai Kalyana Maaligai A/C",
      mapUrl:
        "https://www.google.com/maps/embed?pb=!1m16!1m11!1m3!1d3!2d80.18897968101139!3d13.097544486360421!2m2!1f0!2f90!3m2!1i1024!2i768!4f75!3m3!1m2!1s0x3a52640a3e2d94a5%3A0xe48bca8e1b833b0b!2sAnnai%20Kalyana%20Maaligai%20A%2FC!4v1795145924485",
      directionsUrl:
        "https://www.google.com/maps/dir/?api=1&destination=13.097544486360421,80.18897968101139",
      openMapUrl:
        "https://www.google.com/maps/search/?api=1&query=Annai+Kalyana+Maaligai+A%2FC+13.097544486360421,80.18897968101139",
    },

    wedding: {
      date: "2027-04-23",
      time: "",
      timeConfirmed: false,
      venue: "",
      mapUrl:
        "https://www.google.com/maps/embed?pb=!4v1795145648066!6m8!1m7!1s73_e-FoA52a53ptkV12MoQ!2m2!1d13.09736654648756!2d80.18795029660767!3f184.755!4f0!5f0.7820865974627469",
      directionsUrl:
        "https://www.google.com/maps/dir/?api=1&destination=13.09736654648756,80.18795029660767",
      openMapUrl:
        "https://www.google.com/maps/search/?api=1&query=13.09736654648756,80.18795029660767",
    },
  },

  countdown: {
    date: "2027-04-23",
    time: "",
    timezone: "Asia/Kolkata",
    useDateOnlyUntilTimeConfirmed: true,
  },

  images: {
    couple: "/images/couple.jpg",
  },

  audio: "/audio/wedding-song.mp3",

  // Add family WhatsApp number with country code (e.g. "919876543210") without '+' or spaces
  whatsappNumber: "",

  // Optional custom share URL; falls back to window.location.origin when empty
  invitationUrl: "",
};
