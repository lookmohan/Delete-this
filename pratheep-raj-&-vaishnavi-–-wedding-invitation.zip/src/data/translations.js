export const translations = {
  en: {
    brandShort: "Pratheep & Vaishnavi",
    weddingLabel: "Wedding Invitation",
    weddingDateMain: "April 23, 2027",
    switchLangLabel: "தமிழ்",
    switchLangAria: "Switch website language to Tamil",

    nav: {
      home: "Home",
      invitation: "Invitation",
      couple: "Couple",
      events: "Events",
      countdown: "Countdown",
      gallery: "Gallery",
      wishes: "Send Wishes",
    },

    intro: {
      subtitle: "With the Blessings of Our Families",
      heading: "Wedding Invitation",
      dateLabel: "April 23, 2027",
      enterButton: "Enter Wedding Website",
      skipButton: "Skip Intro",
      replayIntro: "Replay Opening Intro",
    },

    home: {
      kicker: "The Wedding Celebration Of",
      introLead:
        "Two families unite in gratitude, tradition, and joy. Join us as we celebrate the sacred bond of Pratheep Raj A and Vaishnavi R.",
      exploreInvitation: "Explore Invitation",
      exploreEvents: "Explore Events",
      familyHeading: "Two Families, One Joyous Union",
      familySubheading: "With Warm Blessings From Our Parents",
      groomSide: "Groom's Family",
      brideSide: "Bride's Family",
      sonOf: "Son of",
      daughterOf: "Daughter of",
      eventsHeading: "Sacred Ceremonies",
      eventsSubheading: "Three milestones marking our celebration together",
      viewAllEvents: "View Full Schedule & Maps",
      countdownHeading: "Counting Down to the Wedding",
      countdownLink: "Open Full Countdown",
      galleryHeading: "Moments & Traditions",
      gallerySubheading: "Curated frames celebrating the journey ahead",
      viewGallery: "Explore Gallery",
      wishesHeading: "Share Your Heartfelt Blessings",
      wishesBody:
        "Whether joining us in person or sending love from afar, your prayers and wishes mean everything to both families.",
      sendWishesCta: "Send Wishes",
    },

    invitation: {
      kicker: "Traditional Family Invitation",
      title: "Wedding Invitation",
      subtitle: "Cordially Inviting You & Your Family",
      groomLabel: "Groom",
      brideLabel: "Bride",
      parentsPrefixGroom: "Beloved son of",
      parentsPrefixBride: "Beloved daughter of",
      messageParagraphs: [
        "With immense joy and the blessings of our families, we warmly invite you to celebrate the wedding of our beloved ones.",
        "Your presence will make these special moments even more memorable. Please join us with your family, share in our happiness, and bless the couple as they begin their new journey together.",
        "We look forward to celebrating with you!",
      ],
      weddingDateTitle: "Auspicious Wedding Date",
      highlightsTitle: "Ceremony Highlights",
      viewEventsBtn: "View Ceremonies & Venue Maps",
      sendWishesBtn: "Send Your Blessings",
    },

    couple: {
      kicker: "The Bride & Groom",
      title: "Pratheep Raj A & Vaishnavi R",
      subtitle:
        "Honoring the love, traditions, and the two families bringing them together",
      groomTitle: "The Groom",
      brideTitle: "The Bride",
      parentsLabel: "Parents",
      fatherLabel: "Father",
      motherLabel: "Mother",
      photoNote:
        "Couple photograph placeholder — place your portrait at public/images/couple.jpg to display it automatically.",
      invitationCta: "Read Full Invitation",
      eventsCta: "See Wedding Events",
    },

    events: {
      kicker: "Ceremonies & Venues",
      title: "Wedding Events",
      subtitle:
        "Join our families across each ceremony. Exact directions and interactive maps are included below.",
      dateLabel: "Date",
      timeLabel: "Time",
      venueLabel: "Venue",
      venuePending: "Venue to be announced",
      timePending: "Time to be announced",
      getDirections: "Get Directions",
      openInMaps: "Open in Google Maps",
      mapTitleSuffix: "location map",
    },

    countdown: {
      kicker: "Countdown to April 23, 2027",
      title: "Until the Wedding Day",
      days: "Days",
      hours: "Hours",
      minutes: "Minutes",
      seconds: "Seconds",
      timezoneLabel: "Asia/Kolkata (IST)",
      timeConventionNote:
        "The exact wedding ceremony timing is yet to be announced. Until confirmed, this countdown tracks the start of April 23, 2027 (00:00 IST) in Asia/Kolkata.",
      completedTitle: "The Wedding Day Has Arrived",
      completedBody:
        "Thank you for celebrating this joyous milestone with Pratheep Raj A, Vaishnavi R, and both families.",
      exploreEvents: "View Ceremony Details",
    },

    gallery: {
      kicker: "Photo Archive",
      title: "Wedding Gallery",
      subtitle:
        "Cherished portraits and moments from our celebration. Click any frame to view full screen.",
      emptyNoticeTitle: "Add Your Own Photographs",
      emptyNoticeBody:
        "Place your photos inside public/images/gallery/ and register their filenames in src/data/gallery.js. Until then, archival celebration plates are displayed below.",
      placeholderPlate: "Archival Plate",
      closeLightbox: "Close lightbox",
      previousPhoto: "Previous photograph",
      nextPhoto: "Next photograph",
      photoCounter: "of",
    },

    wishes: {
      kicker: "Blessings & Love",
      heading: "Your Wishes Mean the World to Us",
      paragraphs: [
        "Your presence is the greatest gift. If you cannot join us in person, we would still love to receive your heartfelt wishes and blessings for the couple.",
        "Send your love and best wishes as they begin their beautiful journey together.",
      ],
      senderNameLabel: "Your Name (Optional)",
      senderNamePlaceholder: "Enter your name or family name",
      messageLabel: "Your Blessing Message (Optional)",
      messagePlaceholder:
        "Write a warm wish or blessing for Pratheep Raj & Vaishnavi...",
      buttonIdle: "Send Your Blessings",
      buttonProcessing: "Preparing Wishes...",
      statusWhatsappReady: "Your wishes are ready to share.",
      statusShareReady: "Sharing ready — thank you for your blessings.",
      statusCopied: "Invitation link copied!",
      statusSubmitted: "Blessings Sent!",
      helperWhatsapp:
        "WhatsApp opened with your blessing note ready to send to the family.",
      helperShare:
        "Use your device's share menu to pass along your blessings and invitation.",
      helperCopied:
        "The wedding invitation link and greeting have been copied to your clipboard.",
      sendAnother: "Prepare Another Blessing",
      defaultShareText:
        "Warmest wedding blessings to Pratheep Raj A & Vaishnavi R on their upcoming wedding (April 23, 2027)!",
    },

    music: {
      play: "Play wedding music",
      pause: "Pause wedding music",
      playingLabel: "Music On",
      pausedLabel: "Music",
      unavailable:
        "Audio file not found. Add your track at public/audio/wedding-song.mp3.",
    },

    footer: {
      blessingsLine: "With Warm Regards from Both Families",
      groomParents: "Anbu A & Ammu A",
      brideParents: "Ragothaman R & Bharathi R",
      navigateTitle: "Explore",
      musicNote: "Replaceable audio at /audio/wedding-song.mp3",
      copyright: "Pratheep Raj A & Vaishnavi R · April 23, 2027",
    },
  },

  ta: {
    brandShort: "பிரதீப் & வைஷ்ணவி",
    weddingLabel: "திருமண அழைப்பிதழ்",
    weddingDateMain: "ஏப்ரல் 23, 2027",
    switchLangLabel: "Eng",
    switchLangAria: "வலைத்தள மொழியை ஆங்கிலத்திற்கு மாற்றவும்",

    nav: {
      home: "முகப்பு",
      invitation: "அழைப்பிதழ்",
      couple: "மணமக்கள்",
      events: "நிகழ்வுகள்",
      countdown: "கவுண்ட்டவுன்",
      gallery: "புகைப்படங்கள்",
      wishes: "வாழ்த்துகள்",
    },

    intro: {
      subtitle: "இரு குடும்பங்களின் அன்பான ஆசிகளுடன்",
      heading: "திருமண அழைப்பிதழ்",
      dateLabel: "ஏப்ரல் 23, 2027",
      enterButton: "திருமண அழைப்பிதழைத் திறக்க",
      skipButton: "தவிர்க்கவும்",
      replayIntro: "அறிமுகத்தை மீண்டும் காண",
    },

    home: {
      kicker: "இனிதே நடைபெறவுள்ள மங்களத் திருமண விழா",
      introLead:
        "மகிழ்ச்சியும் பாரம்பரியமும் இணைந்த நன்னாளில், பிரதீப் ராஜ் A மற்றும் வைஷ்ணவி R ஆகியோரின் திருமண விழாவில் பங்கேற்க அன்புடன் அழைக்கிறோம்.",
      exploreInvitation: "அழைப்பிதழைக் காண",
      exploreEvents: "நிகழ்வுகளைக் காண",
      familyHeading: "இரு குடும்பங்களின் இனிய சங்கமம்",
      familySubheading: "பெற்றோர்களின் அன்பான அழைப்பும் ஆசிகளும்",
      groomSide: "மணமகன் குடும்பத்தினர்",
      brideSide: "மணமகள் குடும்பத்தினர்",
      sonOf: "மகன்",
      daughterOf: "மகள்",
      eventsHeading: "திருமண நிகழ்வுகள்",
      eventsSubheading: "நமது குடும்ப மகிழ்ச்சியைப் பகிர்ந்துகொள்ளும் மூன்று நன்னிகழ்வுகள்",
      viewAllEvents: "முழு நிகழ்வுகள் மற்றும் வரைபடம்",
      countdownHeading: "திருமண நன்னாளுக்கான எண்ணிக்கை",
      countdownLink: "முழு கவுண்ட்டவுனைக் காண",
      galleryHeading: "மலரும் நினைவுகள்",
      gallerySubheading: "பாரம்பரியமும் அழகும் நிறைந்த நினைவுத் தொகுப்பு",
      viewGallery: "புகைப்படத் தொகுப்பைக் காண",
      wishesHeading: "உங்கள் அன்பான வாழ்த்துகளைப் பகிருங்கள்",
      wishesBody:
        "நேரிலும் தொலைதூரத்திலும் இருந்து நீங்கள் வழங்கும் அன்பும் ஆசிகளும் மணமக்களின் புதிய பயணத்திற்குப் பெரும் பலமாக அமையும்.",
      sendWishesCta: "வாழ்த்து அனுப்ப",
    },

    invitation: {
      kicker: "பாரம்பரியக் குடும்ப அழைப்பிதழ்",
      title: "திருமண அழைப்பிதழ்",
      subtitle: "தங்களையும் தங்கள் குடும்பத்தினரையும் அன்புடன் அழைக்கிறோம்",
      groomLabel: "மணமகன்",
      brideLabel: "மணமகள்",
      parentsPrefixGroom: "பெற்றோர்",
      parentsPrefixBride: "பெற்றோர்",
      messageParagraphs: [
        "எங்கள் குடும்பத்தின் மகிழ்ச்சியான இந்த நன்னாளில், எங்கள் அன்பிற்குரிய மணமக்களின் திருமண விழாவில் தங்களையும் தங்கள் குடும்பத்தினரையும் அன்புடன் அழைக்கிறோம்.",
        "தங்களின் வருகையும், அன்பான வாழ்த்துகளும், ஆசீர்வாதங்களும் எங்களுக்கு மிகுந்த மகிழ்ச்சியைத் தரும்.",
        "மணமக்களின் புதிய வாழ்க்கைப் பயணம் சிறப்பாக அமைய தங்கள் அன்பையும் ஆசிகளையும் வழங்கி, இந்த மகிழ்ச்சியான தருணத்தில் எங்களுடன் இணைந்திட அன்புடன் வேண்டுகிறோம்.",
      ],
      weddingDateTitle: "மங்களத் திருமண நாள்",
      highlightsTitle: "விழா நிகழ்வுகள்",
      viewEventsBtn: "நிகழ்வுகள் மற்றும் வழித்தடம்",
      sendWishesBtn: "உங்கள் வாழ்த்துகளைப் பகிருங்கள்",
    },

    couple: {
      kicker: "மணமக்கள் அறிமுகம்",
      title: "பிரதீப் ராஜ் A & வைஷ்ணவி R",
      subtitle: "அன்பும் பாரம்பரியமும் இணையும் இரு குடும்பங்களின் மகிழ்ச்சிப் பெருவிழா",
      groomTitle: "மணமகன்",
      brideTitle: "மணமகள்",
      parentsLabel: "பெற்றோர்",
      fatherLabel: "தந்தை",
      motherLabel: "தாய்",
      photoNote:
        "மணமக்கள் புகைப்பட இடம் — public/images/couple.jpg கோப்பைச் சேர்த்தால் புகைப்படம் தானாகத் தோன்றும்.",
      invitationCta: "முழு அழைப்பிதழைப் படிக்க",
      eventsCta: "திருமண நிகழ்வுகளைக் காண",
    },

    events: {
      kicker: "நிகழ்வுகள் மற்றும் இடங்கள்",
      title: "திருமண நிகழ்வுகள்",
      subtitle:
        "ஒவ்வொரு மங்கள நிகழ்விலும் எங்களுடன் இணைந்திடுங்கள். வழித்தடமும் வரைபடமும் கீழே இணைக்கப்பட்டுள்ளன.",
      dateLabel: "தேதி",
      timeLabel: "நேரம்",
      venueLabel: "இடம்",
      venuePending: "இடம் விரைவில் அறிவிக்கப்படும்",
      timePending: "நேரம் விரைவில் அறிவிக்கப்படும்",
      getDirections: "வழித்தடம் காண",
      openInMaps: "Google Maps-இல் திறக்க",
      mapTitleSuffix: "இட வரைபடம்",
    },

    countdown: {
      kicker: "ஏப்ரல் 23, 2027 நன்னாளுக்கான எண்ணிக்கை",
      title: "திருமண நாளுக்கான கவுண்ட்டவுன்",
      days: "நாட்கள்",
      hours: "மணி",
      minutes: "நிமிடங்கள்",
      seconds: "விநாடிகள்",
      timezoneLabel: "இந்திய நேரப்படி (Asia/Kolkata)",
      timeConventionNote:
        "திருமண முகூர்த்த நேரம் இன்னும் அறிவிக்கப்படவில்லை. நேரம் உறுதிசெய்யப்படும் வரை, இந்த எண்ணிக்கை ஏப்ரல் 23, 2027 இந்திய நேரப்படி நள்ளிரவு 12:00 (நாள் தொடக்கம்) அடிப்படையில் காட்டப்படுகிறது.",
      completedTitle: "திருமண நன்னாள் வந்துவிட்டது",
      completedBody:
        "பிரதீப் ராஜ் A, வைஷ்ணவி R மற்றும் இரு குடும்பத்தினருடன் இந்த மகிழ்ச்சியான தருணத்தைக் கொண்டாடுவதற்கு நன்றி.",
      exploreEvents: "நிகழ்வு விவரங்களைக் காண",
    },

    gallery: {
      kicker: "நினைவுத் தொகுப்பு",
      title: "புகைப்படத் தொகுப்பு",
      subtitle:
        "திருமண நிகழ்வுகளின் இனிய தருணங்கள். முழுமையாகக் காண எந்தப் படத்தையும் தட்டவும்.",
      emptyNoticeTitle: "உங்கள் புகைப்படங்களைச் சேர்க்க",
      emptyNoticeBody:
        "public/images/gallery/ கோப்புறையில் உங்கள் புகைப்படங்களைச் சேர்த்து, src/data/gallery.js கோப்பில் பெயர்களைப் புதுப்பிக்கவும். அதுவரை பாரம்பரிய அலங்காரத் தகடுகள் கீழே காட்டப்படுகின்றன.",
      placeholderPlate: "நினைவுத் தகடு",
      closeLightbox: "படத்தை மூட",
      previousPhoto: "முந்தைய படம்",
      nextPhoto: "அடுத்த படம்",
      photoCounter: "/",
    },

    wishes: {
      kicker: "அன்பும் ஆசிகளும்",
      heading: "தங்களின் வாழ்த்துகளே எங்களுக்கு மிகப் பெரிய பரிசு",
      paragraphs: [
        "இந்த மகிழ்ச்சியான தருணத்தில் தங்களின் வருகையும் அன்பான வாழ்த்துகளும் எங்களுக்கு மிகவும் சிறப்பானவை.",
        "நேரில் கலந்துகொள்ள முடியாவிட்டாலும், மணமக்களின் புதிய வாழ்க்கைப் பயணத்திற்கு தங்களின் அன்பையும் ஆசிகளையும் வாழ்த்துகளையும் பகிர்ந்துகொள்ளுங்கள்.",
      ],
      senderNameLabel: "உங்கள் பெயர் (விருப்பத்திற்கேற்ப)",
      senderNamePlaceholder: "உங்கள் பெயர் அல்லது குடும்பப் பெயர்",
      messageLabel: "உங்கள் வாழ்த்துச் செய்தி (விருப்பத்திற்கேற்ப)",
      messagePlaceholder:
        "பிரதீப் ராஜ் & வைஷ்ணவிக்கு உங்கள் அன்பான வாழ்த்துகளை எழுதுங்கள்...",
      buttonIdle: "உங்கள் வாழ்த்துகளைப் பகிருங்கள்",
      buttonProcessing: "வாழ்த்துகள் தயாராகின்றன...",
      statusWhatsappReady: "உங்கள் வாழ்த்துகள் பகிரத் தயாராக உள்ளன.",
      statusShareReady: "பகிர்வு தயார் — உங்கள் அன்பான வாழ்த்துகளுக்கு நன்றி.",
      statusCopied: "அழைப்பிதழ் இணைப்பு நகலெடுக்கப்பட்டது!",
      statusSubmitted: "வாழ்த்துகள் அனுப்பப்பட்டன!",
      helperWhatsapp:
        "குடும்பத்தினருக்குப் பகிர உங்கள் வாழ்த்துச் செய்தியுடன் WhatsApp தயாராக உள்ளது.",
      helperShare:
        "உங்கள் வாழ்த்துகளையும் அழைப்பிதழையும் பகிர பகிர்வுத் திரையைப் பயன்படுத்தவும்.",
      helperCopied:
        "திருமண அழைப்பிதழ் இணைப்பும் வாழ்த்தும் நகலெடுக்கப்பட்டன.",
      sendAnother: "மற்றொரு வாழ்த்தைப் பகிர",
      defaultShareText:
        "பிரதீப் ராஜ் A & வைஷ்ணவி R ஆகியோரின் திருமண நன்னாளுக்கு (ஏப்ரல் 23, 2027) மனமார்ந்த வாழ்த்துகள்!",
    },

    music: {
      play: "மங்கள இசையை இயக்க",
      pause: "இசையை நிறுத்த",
      playingLabel: "இசை இயங்குகிறது",
      pausedLabel: "இசை",
      unavailable:
        "இசைக் கோப்பு இல்லை. public/audio/wedding-song.mp3 கோப்பைச் சேர்க்கவும்.",
    },

    footer: {
      blessingsLine: "இரு குடும்பங்களின் அன்புடன்",
      groomParents: "அன்பு A & அம்மு A",
      brideParents: "ரகோத்தமன் R & பாரதி R",
      navigateTitle: "பக்கங்கள்",
      musicNote: "/audio/wedding-song.mp3 வழியாக இசையை மாற்றலாம்",
      copyright: "பிரதீப் ராஜ் A & வைஷ்ணவி R · ஏப்ரல் 23, 2027",
    },
  },
};
