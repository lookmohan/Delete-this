/**
 * Central Gallery Configuration
 *
 * To add your own wedding photographs:
 * 1. Place image files inside: public/images/gallery/
 *    (e.g., public/images/gallery/engagement-01.jpg)
 * 2. Update the `src` property below with "/images/gallery/your-file.jpg"
 *    or add new entries following the same structure.
 *
 * When `src` is empty or the file has not been added yet, an editorial
 * South Indian archival plate is shown without broken image icons.
 */
export const galleryPhotos = [
  {
    id: "plate-01",
    src: "",
    alt: {
      en: "Couple portrait archival plate",
      ta: "மணமக்கள் நினைவுப் புகைப்படம்",
    },
    caption: {
      en: "The Betrothal Promise",
      ta: "நிச்சயதார்த்த நன்னாள்",
    },
    aspect: "portrait",
  },
  {
    id: "plate-02",
    src: "",
    alt: {
      en: "Traditional silk and jasmine floral motif",
      ta: "மல்லிகை மற்றும் பட்டு அலங்காரம்",
    },
    caption: {
      en: "Jasmine & Silk Traditions",
      ta: "மல்லிகையும் பட்டுப் பாரம்பரியமும்",
    },
    aspect: "landscape",
  },
  {
    id: "plate-03",
    src: "",
    alt: {
      en: "Sacred brass lamp and kolam motif",
      ta: "குத்துவிளக்கு மற்றும் கோல அலங்காரம்",
    },
    caption: {
      en: "Kuthuvilakku & Kolam",
      ta: "மங்களக் குத்துவிளக்கு",
    },
    aspect: "square",
  },
  {
    id: "plate-04",
    src: "",
    alt: {
      en: "Reception evening celebration placeholder",
      ta: "வரவேற்பு விழா நினைவுப் புகைப்படம்",
    },
    caption: {
      en: "Reception Evening",
      ta: "வரவேற்பு மாலை",
    },
    aspect: "landscape",
  },
  {
    id: "plate-05",
    src: "",
    alt: {
      en: "Family blessings ceremony placeholder",
      ta: "பெற்றோர் மற்றும் குடும்ப ஆசிகள்",
    },
    caption: {
      en: "Blessings of Both Families",
      ta: "இரு குடும்பங்களின் ஆசீர்வாதம்",
    },
    aspect: "portrait",
  },
  {
    id: "plate-06",
    src: "",
    alt: {
      en: "Muhurtham wedding day placeholder",
      ta: "திருமண முகூர்த்த நன்னாள்",
    },
    caption: {
      en: "The Wedding Morning",
      ta: "திருமண நன்னாள் காலை",
    },
    aspect: "square",
  },
];
