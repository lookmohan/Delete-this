import { weddingConfig } from "./weddingConfig";

export function formatTimeDisplay(timeStr, timeConfirmed, lang) {
  if (!timeConfirmed || !timeStr) {
    return lang === "ta"
      ? "நேரம் விரைவில் அறிவிக்கப்படும்"
      : "Time to be announced";
  }

  const [hoursRaw, minutesRaw] = timeStr.split(":").map(Number);
  if (Number.isNaN(hoursRaw) || Number.isNaN(minutesRaw)) {
    return timeStr;
  }

  const periodEn = hoursRaw >= 12 ? "PM" : "AM";
  const hours12 = hoursRaw % 12 || 12;
  const paddedMins = String(minutesRaw).padStart(2, "0");

  if (lang === "ta") {
    let periodTa = "மணி";
    if (hoursRaw >= 16 && hoursRaw < 19) periodTa = "மாலை";
    else if (hoursRaw >= 12 && hoursRaw < 16) periodTa = "மதியம்";
    else if (hoursRaw >= 19) periodTa = "இரவு";
    else periodTa = "காலை";
    return `${periodTa} ${hours12}:${paddedMins}`;
  }

  return `${hours12}:${paddedMins} ${periodEn}`;
}

export function formatEventDate(isoDate, lang) {
  const [year, month, day] = isoDate.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));

  if (lang === "ta") {
    const monthsTa = [
      "ஜனவரி",
      "பிப்ரவரி",
      "மார்ச்",
      "ஏப்ரல்",
      "மே",
      "ஜூன்",
      "ஜூலை",
      "ஆகஸ்ட்",
      "செப்டம்பர்",
      "அக்டோபர்",
      "நவம்பர்",
      "டிசம்பர்",
    ];
    const weekdaysTa = [
      "ஞாயிறு",
      "திங்கள்",
      "செவ்வாய்",
      "புதன்",
      "வியாழன்",
      "வெள்ளி",
      "சனி",
    ];
    return `${monthsTa[month - 1]} ${day}, ${year} · ${weekdaysTa[date.getUTCDay()]}`;
  }

  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  });
}

export const weddingEventsList = [
  {
    id: "engagement",
    order: "01",
    title: {
      en: "Engagement",
      ta: "நிச்சயதார்த்தம்",
    },
    subtitle: {
      en: "Formal Betrothal & Exchange of Blessings",
      ta: "மணமக்கள் நிச்சயமும் குடும்ப ஆசிகளும்",
    },
    ...weddingConfig.events.engagement,
  },
  {
    id: "reception",
    order: "02",
    title: {
      en: "Reception",
      ta: "திருமண வரவேற்பு",
    },
    subtitle: {
      en: "Evening Celebration & Fellowship",
      ta: "மாலையில் இனிய வரவேற்பு விருந்து",
    },
    ...weddingConfig.events.reception,
  },
  {
    id: "wedding",
    order: "03",
    title: {
      en: "Wedding",
      ta: "திருமணம்",
    },
    subtitle: {
      en: "Sacred Muhurtham Ceremony",
      ta: "மங்களகரமான திருமாங்கல்ய தாரணம்",
    },
    ...weddingConfig.events.wedding,
  },
];
