import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useCountdown } from "../hooks/useCountdown";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";

function DigitTile({ value, label, compact = false, dark = false }) {
  const prefersReducedMotion = useReducedMotion();
  const formatted = String(value).padStart(2, "0");

  return (
    <div
      className={`flex flex-col items-center justify-center rounded-xl border ${
        dark
          ? "border-[#E9BFA5]/25 bg-[#FFF0E8]/5 text-[#FFF0E8]"
          : "border-[#B66A54]/30 bg-[#FFF0E8] text-[#351B29]"
      } ${compact ? "px-3 py-4 sm:px-5 sm:py-5" : "px-4 py-6 sm:px-6 sm:py-8"}`}
    >
      <div className="relative flex h-12 items-center justify-center overflow-hidden sm:h-16">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.span
            key={formatted}
            initial={prefersReducedMotion ? false : { y: 14, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={prefersReducedMotion ? false : { y: -14, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE_LUXURY }}
            className={`tabular-nums font-serif font-semibold tracking-tight ${
              compact ? "text-3xl sm:text-4xl" : "text-4xl sm:text-6xl"
            } ${dark ? "text-[#FFF0E8]" : "text-[#762C3A]"}`}
          >
            {formatted}
          </motion.span>
        </AnimatePresence>
      </div>
      <span
        className={`mt-1.5 text-xs font-medium tracking-[0.14em] uppercase sm:text-sm ${
          dark ? "text-[#E9BFA5]" : "text-[#351B29]/75"
        }`}
      >
        {label}
      </span>
    </div>
  );
}

export function CountdownTimer({ compact = false, dark = false }) {
  const { days, hours, minutes, seconds, isCompleted } = useCountdown();
  const { t } = useLanguage();

  if (isCompleted) {
    return (
      <div
        className={`rounded-2xl border p-8 text-center ${
          dark
            ? "border-[#E9BFA5]/30 bg-[#FFF0E8]/5 text-[#FFF0E8]"
            : "border-[#B66A54]/30 bg-[#FFF0E8] text-[#351B29]"
        }`}
      >
        <h3 className="font-serif text-2xl font-semibold sm:text-3xl">
          {t.countdown.completedTitle}
        </h3>
        <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed opacity-85 sm:text-base">
          {t.countdown.completedBody}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-5">
      <DigitTile value={days} label={t.countdown.days} compact={compact} dark={dark} />
      <DigitTile value={hours} label={t.countdown.hours} compact={compact} dark={dark} />
      <DigitTile value={minutes} label={t.countdown.minutes} compact={compact} dark={dark} />
      <DigitTile value={seconds} label={t.countdown.seconds} compact={compact} dark={dark} />
    </div>
  );
}
