import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";
import { KolamMandala } from "./OrnamentalMotifs";

export function CouplePortraitFrame({
  className = "",
  aspectClass = "aspect-[4/5]",
  altText,
  placeholderNote,
  priority = false,
}) {
  const [imageMissing, setImageMissing] = useState(false);
  const prefersReducedMotion = useReducedMotion();

  return (
    <motion.div
      className={`relative overflow-hidden rounded-xl border border-[#B66A54]/30 bg-[#351B29] ${aspectClass} ${className}`}
      initial={
        prefersReducedMotion
          ? false
          : { clipPath: "inset(8% 5% 8% 5% round 12px)", opacity: 0 }
      }
      animate={{ clipPath: "inset(0% 0% 0% 0% round 12px)", opacity: 1 }}
      transition={{ duration: 1.0, ease: EASE_LUXURY }}
    >
      {!imageMissing ? (
        <motion.img
          src={weddingConfig.images.couple}
          alt={altText}
          loading={priority ? "eager" : "lazy"}
          referrerPolicy="no-referrer"
          onError={() => setImageMissing(true)}
          className="h-full w-full object-cover"
          initial={prefersReducedMotion ? false : { scale: 1.07 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.4, ease: EASE_LUXURY }}
        />
      ) : (
        <div className="kolam-dark-pattern relative flex h-full w-full flex-col items-center justify-center p-6 text-center text-[#FFF0E8]">
          {/* Delicate inner frame */}
          <div className="pointer-events-none absolute inset-4 rounded-lg border border-[#E9BFA5]/25" />

          <KolamMandala className="mb-5 h-32 w-32 opacity-85 sm:h-40 sm:w-40" light />

          <p className="font-serif text-2xl tracking-wide text-[#FFF0E8] sm:text-3xl">
            {weddingConfig.groom.name}
          </p>
          <span className="my-1.5 font-serif text-lg italic text-[#E9BFA5]">&amp;</span>
          <p className="font-serif text-2xl tracking-wide text-[#FFF0E8] sm:text-3xl">
            {weddingConfig.bride.name}
          </p>

          {placeholderNote && (
            <p className="mt-5 max-w-xs text-xs leading-relaxed text-[#E9BFA5]/75">
              {placeholderNote}
            </p>
          )}
        </div>
      )}
    </motion.div>
  );
}
