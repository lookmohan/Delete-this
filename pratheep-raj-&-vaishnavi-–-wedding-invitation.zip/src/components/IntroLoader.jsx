import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";
import { JasminePetalsLayer, KolamMandala, TempleDivider } from "./OrnamentalMotifs";
import { InvitationReveal } from "./InvitationReveal";

export function IntroLoader({ onComplete }) {
  const { t, toggleLanguage } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const [stage, setStage] = useState(prefersReducedMotion ? 4 : 1);

  // Preload couple image quietly so Home page reveals immediately
  useEffect(() => {
    const img = new Image();
    img.src = weddingConfig.images.couple;
  }, []);

  useEffect(() => {
    if (prefersReducedMotion) {
      setStage(4);
      return undefined;
    }

    const t1 = window.setTimeout(() => setStage(2), 950);
    const t2 = window.setTimeout(() => setStage(3), 1850);
    const t3 = window.setTimeout(() => setStage(4), 2650);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
    };
  }, [prefersReducedMotion]);

  return (
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-label={t.intro.heading}
      className="kolam-dark-pattern fixed inset-0 z-50 flex flex-col items-center justify-between overflow-y-auto bg-[#351B29] px-4 py-6 text-[#FFF0E8] sm:px-8 sm:py-8"
      initial={{ opacity: 1 }}
      exit={{
        opacity: 0,
        scale: 1.03,
        transition: { duration: 0.65, ease: EASE_LUXURY },
      }}
    >
      <JasminePetalsLayer count={10} light />

      {/* Top Bar: Language Toggle & Skip Intro */}
      <div className="relative z-30 flex w-full max-w-5xl items-center justify-between">
        <button
          type="button"
          onClick={toggleLanguage}
          aria-label={t.switchLangAria}
          className="min-h-[44px] rounded-lg border border-[#E9BFA5]/30 px-4 py-2 text-sm font-medium text-[#E9BFA5] transition-colors hover:border-[#E9BFA5] hover:text-[#FFF0E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5]"
        >
          {t.switchLangLabel}
        </button>

        <button
          type="button"
          onClick={onComplete}
          className="min-h-[44px] rounded-lg px-4 py-2 text-sm font-medium text-[#E9BFA5]/85 transition-colors hover:text-[#FFF0E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5]"
        >
          {t.intro.skipButton}
        </button>
      </div>

      {/* Center Stage: Kolam + Curtain Invitation Reveal */}
      <div className="relative z-20 my-auto flex w-full max-w-2xl flex-col items-center py-6 text-center">
        {/* Stage 1 & 2: Forming Kolam Mandala above/around reveal */}
        <motion.div
          className="mb-6 flex flex-col items-center"
          initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: EASE_LUXURY }}
        >
          <KolamMandala
            className="h-28 w-28 sm:h-36 sm:w-36"
            animated={!prefersReducedMotion}
            light
          />
        </motion.div>

        {/* Stage 3: Center-parting curtain panels revealing the Wedding Identity */}
        <InvitationReveal isOpen={stage >= 3}>
          <motion.p
            className="text-xs font-medium tracking-[0.22em] text-[#E9BFA5] uppercase sm:text-sm"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: stage >= 2 ? 1 : 0, y: stage >= 2 ? 0 : 10 }}
            transition={{ duration: 0.6, ease: EASE_LUXURY }}
          >
            {t.intro.subtitle}
          </motion.p>

          <motion.h1
            className="mt-3 font-serif text-2xl font-medium tracking-wide text-[#E9BFA5] sm:text-3xl"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: stage >= 2 ? 1 : 0, y: stage >= 2 ? 0 : 10 }}
            transition={{ duration: 0.65, delay: 0.1, ease: EASE_LUXURY }}
          >
            {t.intro.heading}
          </motion.h1>

          <TempleDivider className="my-5" light />

          <motion.div
            className="space-y-1.5"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: stage >= 3 ? 1 : 0, y: stage >= 3 ? 0 : 14 }}
            transition={{ duration: 0.75, delay: 0.25, ease: EASE_LUXURY }}
          >
            <p className="font-serif text-3xl font-semibold tracking-wide text-[#FFF0E8] sm:text-5xl">
              {weddingConfig.groom.name}
            </p>
            <p className="font-serif text-xl italic text-[#E9BFA5] sm:text-2xl">&amp;</p>
            <p className="font-serif text-3xl font-semibold tracking-wide text-[#FFF0E8] sm:text-5xl">
              {weddingConfig.bride.name}
            </p>
          </motion.div>

          <motion.p
            className="mt-6 text-sm font-medium tracking-[0.18em] text-[#E9BFA5] uppercase sm:text-base"
            initial={prefersReducedMotion ? false : { opacity: 0 }}
            animate={{ opacity: stage >= 3 ? 1 : 0 }}
            transition={{ duration: 0.65, delay: 0.4, ease: EASE_LUXURY }}
          >
            {t.intro.dateLabel}
          </motion.p>

          {/* Stage 4: Enter Wedding Website CTA */}
          <motion.div
            className="mt-8 flex justify-center"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
            animate={{
              opacity: stage >= 4 ? 1 : 0,
              y: stage >= 4 ? 0 : 12,
            }}
            transition={{ duration: 0.55, ease: EASE_LUXURY }}
          >
            <button
              type="button"
              onClick={onComplete}
              className="group inline-flex min-h-[48px] items-center gap-2.5 rounded-xl bg-[#762C3A] px-7 py-3.5 text-sm font-semibold tracking-wide text-[#FFF0E8] shadow-lg transition-all hover:scale-[1.02] hover:bg-[#8B3545] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5] sm:text-base"
            >
              <span>{t.intro.enterButton}</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        </InvitationReveal>
      </div>

      {/* Bottom subtle ornament */}
      <div className="relative z-20 text-xs tracking-widest text-[#E9BFA5]/60 uppercase">
        {t.brandShort}
      </div>
    </motion.div>
  );
}
