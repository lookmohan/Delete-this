import { useLanguage } from "../context/LanguageContext";

export function LanguageSwitcher({ className = "" }) {
  const { t, toggleLanguage } = useLanguage();

  return (
    <button
      type="button"
      onClick={toggleLanguage}
      aria-label={t.switchLangAria}
      className={`inline-flex min-h-[40px] min-w-[58px] items-center justify-center rounded-lg border border-[#762C3A]/30 bg-[#FFF0E8] px-3.5 py-1.5 text-sm font-semibold whitespace-nowrap shrink-0 text-[#762C3A] transition-colors hover:border-[#762C3A] hover:bg-[#762C3A] hover:text-[#FFF0E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] ${className}`}
    >
      {t.switchLangLabel}
    </button>
  );
}
