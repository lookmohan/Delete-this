import { Link, useLocation } from "react-router-dom";
import { CalendarDays, Heart } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

export function MobileActionBar() {
  const { t } = useLanguage();
  const location = useLocation();

  return (
    <nav
      aria-label="Quick mobile actions"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-[#B66A54]/25 bg-[#FFF0E8]/95 backdrop-blur-md md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="grid grid-cols-2 divide-x divide-[#B66A54]/20">
        <Link
          to="/events"
          className={`flex min-h-[52px] items-center justify-center gap-2 px-3 text-sm font-medium transition-colors ${
            location.pathname === "/events"
              ? "bg-[#762C3A]/10 text-[#762C3A]"
              : "text-[#351B29] hover:text-[#762C3A]"
          }`}
        >
          <CalendarDays className="h-4 w-4 shrink-0" />
          <span className="truncate">{t.nav.events}</span>
        </Link>

        <Link
          to="/wishes"
          className={`flex min-h-[52px] items-center justify-center gap-2 px-3 text-sm font-semibold transition-colors ${
            location.pathname === "/wishes"
              ? "bg-[#762C3A] text-[#FFF0E8]"
              : "text-[#762C3A] hover:bg-[#762C3A]/10"
          }`}
        >
          <Heart className="h-4 w-4 shrink-0" />
          <span className="truncate">{t.nav.wishes}</span>
        </Link>
      </div>
    </nav>
  );
}
