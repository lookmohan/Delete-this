import { useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Menu } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { MobileMenu } from "./MobileMenu";
import { EASE_LUXURY } from "../animations/motionVariants";

export const NAV_ROUTES = [
  { path: "/", key: "home" },
  { path: "/invitation", key: "invitation" },
  { path: "/couple", key: "couple" },
  { path: "/events", key: "events" },
  { path: "/countdown", key: "countdown" },
  { path: "/gallery", key: "gallery" },
  { path: "/wishes", key: "wishes" },
];

export function Navbar() {
  const { t } = useLanguage();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-[#B66A54]/20 bg-[#FFF0E8]/95 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          {/* Brand Wordmark */}
          <Link
            to="/"
            className="max-w-[200px] truncate font-serif text-lg font-semibold tracking-wide whitespace-nowrap shrink-0 text-[#351B29] transition-colors hover:text-[#762C3A] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#762C3A] sm:max-w-none sm:text-2xl"
          >
            {t.brandShort}
          </Link>

          {/* Desktop Navigation */}
          <nav
            aria-label="Primary"
            className="hidden items-center gap-6 lg:flex xl:gap-7"
          >
            {NAV_ROUTES.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={`relative py-2 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#762C3A] ${
                    isActive
                      ? "text-[#762C3A]"
                      : "text-[#351B29]/80 hover:text-[#762C3A]"
                  }`}
                >
                  {t.nav[item.key]}
                  {isActive && (
                    <motion.span
                      layoutId="activeNavUnderline"
                      transition={{ duration: 0.3, ease: EASE_LUXURY }}
                      className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-[#762C3A]"
                    />
                  )}
                </NavLink>
              );
            })}
          </nav>

          {/* Right Controls: Language Switcher + Mobile Hamburger */}
          <div className="flex items-center gap-2.5 shrink-0">
            <LanguageSwitcher />

            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              aria-expanded={mobileOpen}
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-[#B66A54]/30 text-[#351B29] transition-colors hover:border-[#762C3A] hover:text-[#762C3A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <MobileMenu isOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  );
}
