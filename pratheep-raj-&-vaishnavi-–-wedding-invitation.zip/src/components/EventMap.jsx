import { ExternalLink, Navigation } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";

export function EventMap({ event }) {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const eventTitle = event.title[language] || event.title.en;

  return (
    <motion.div
      initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.65, ease: EASE_LUXURY }}
      className="space-y-4"
    >
      <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl border border-[#B66A54]/30 bg-[#E9BFA5]/20 sm:aspect-[16/9]">
        <iframe
          src={event.mapUrl}
          title={`${eventTitle} ${t.events.mapTitleSuffix}`}
          loading="lazy"
          allowFullScreen
          referrerPolicy="no-referrer-when-downgrade"
          className="h-full w-full border-0"
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <a
          href={event.directionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#762C3A] px-5 py-2.5 text-sm font-semibold text-[#FFF0E8] transition-all hover:scale-[1.02] hover:bg-[#8B3545] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A]"
        >
          <Navigation className="h-4 w-4 shrink-0" />
          <span>{t.events.getDirections}</span>
        </a>

        <a
          href={event.openMapUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-[#762C3A]/35 px-5 py-2.5 text-sm font-medium text-[#762C3A] transition-colors hover:border-[#762C3A] hover:bg-[#762C3A]/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A]"
        >
          <ExternalLink className="h-4 w-4 shrink-0" />
          <span>{t.events.openInMaps}</span>
        </a>
      </div>
    </motion.div>
  );
}
