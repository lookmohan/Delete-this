import { motion, useReducedMotion } from "framer-motion";
import { EASE_LUXURY } from "../animations/motionVariants";

export function InvitationReveal({ isOpen, children }) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-[#E9BFA5]/35 bg-[#351B29]/90 px-6 py-10 shadow-2xl sm:px-10 sm:py-12">
      {/* Subtle inner light glow behind parting panels */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        initial={false}
        animate={{
          opacity: isOpen ? 1 : 0.25,
          scale: isOpen ? 1 : 0.94,
        }}
        transition={{ duration: 0.9, ease: EASE_LUXURY }}
        style={{
          background:
            "radial-gradient(circle at 50% 45%, rgba(233, 191, 165, 0.16) 0%, rgba(53, 27, 41, 0) 70%)",
        }}
      />

      {/* Revealed Inner Invitation Content */}
      <motion.div
        className="relative z-10"
        initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.94 }}
        animate={{
          opacity: isOpen ? 1 : 0,
          scale: isOpen ? 1 : 0.94,
        }}
        transition={{
          duration: prefersReducedMotion ? 0.15 : 0.85,
          delay: isOpen && !prefersReducedMotion ? 0.2 : 0,
          ease: EASE_LUXURY,
        }}
      >
        {children}
      </motion.div>

      {/* Left Decorative Curtain Panel */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 z-20 flex w-1/2 items-center justify-end border-r border-[#E9BFA5]/45 bg-[#351B29] pr-2"
        initial={false}
        animate={{
          x: isOpen ? "-102%" : "0%",
          opacity: isOpen ? 0 : 1,
        }}
        transition={{
          duration: prefersReducedMotion ? 0.2 : 1.05,
          ease: EASE_LUXURY,
        }}
      >
        <div className="h-[82%] w-[86%] rounded-l-xl border border-r-0 border-[#E9BFA5]/25 p-3">
          <div className="h-full w-full rounded-l-lg border border-r-0 border-[#B66A54]/30" />
        </div>
      </motion.div>

      {/* Right Decorative Curtain Panel */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 right-0 z-20 flex w-1/2 items-center justify-start border-l border-[#E9BFA5]/45 bg-[#351B29] pl-2"
        initial={false}
        animate={{
          x: isOpen ? "102%" : "0%",
          opacity: isOpen ? 0 : 1,
        }}
        transition={{
          duration: prefersReducedMotion ? 0.2 : 1.05,
          ease: EASE_LUXURY,
        }}
      >
        <div className="h-[82%] w-[86%] rounded-r-xl border border-l-0 border-[#E9BFA5]/25 p-3">
          <div className="h-full w-full rounded-r-lg border border-l-0 border-[#B66A54]/30" />
        </div>
      </motion.div>
    </div>
  );
}
