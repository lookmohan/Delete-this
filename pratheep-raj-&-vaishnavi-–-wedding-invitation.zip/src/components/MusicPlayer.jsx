import { AnimatePresence, motion } from "framer-motion";
import { Pause, Play, Volume2, X } from "lucide-react";
import { useMusic } from "../context/MusicContext";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";

export function MusicPlayer() {
  const { isPlaying, showUnavailableNotice, dismissNotice, togglePlay } = useMusic();
  const { t } = useLanguage();

  return (
    <div className="fixed right-4 bottom-20 z-40 flex flex-col items-end gap-2 md:right-6 md:bottom-6">
      <AnimatePresence>
        {showUnavailableNotice && (
          <motion.div
            role="status"
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.96 }}
            transition={{ duration: 0.25, ease: EASE_LUXURY }}
            className="flex max-w-xs items-start gap-2 rounded-xl border border-[#E9BFA5]/40 bg-[#351B29] px-3.5 py-2.5 text-xs leading-relaxed text-[#FFF0E8] shadow-lg"
          >
            <span className="flex-1">{t.music.unavailable}</span>
            <button
              type="button"
              onClick={dismissNotice}
              aria-label="Dismiss notice"
              className="mt-0.5 text-[#E9BFA5] hover:text-[#FFF0E8]"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        type="button"
        onClick={togglePlay}
        aria-label={isPlaying ? t.music.pause : t.music.play}
        aria-pressed={isPlaying}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        className={`inline-flex min-h-[44px] items-center gap-2 rounded-full border px-4 py-2 text-xs font-semibold shadow-lg transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] ${
          isPlaying
            ? "border-[#E9BFA5]/50 bg-[#762C3A] text-[#FFF0E8]"
            : "border-[#B66A54]/40 bg-[#351B29] text-[#E9BFA5] hover:bg-[#762C3A] hover:text-[#FFF0E8]"
        }`}
      >
        {isPlaying ? (
          <>
            <Pause className="h-4 w-4 shrink-0" />
            <span className="whitespace-nowrap">{t.music.playingLabel}</span>
            <Volume2 className="h-3.5 w-3.5 shrink-0 text-[#E9BFA5]" />
          </>
        ) : (
          <>
            <Play className="h-4 w-4 shrink-0" />
            <span className="whitespace-nowrap">{t.music.pausedLabel}</span>
          </>
        )}
      </motion.button>
    </div>
  );
}
