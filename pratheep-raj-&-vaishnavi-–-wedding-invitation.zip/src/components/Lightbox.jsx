import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";
import { KolamMandala } from "./OrnamentalMotifs";

export function Lightbox({ items, activeIndex, onClose, onNavigate }) {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const [failedId, setFailedId] = useState(null);

  const isOpen = activeIndex !== null && activeIndex >= 0 && activeIndex < items.length;
  const activeItem = isOpen ? items[activeIndex] : null;

  useEffect(() => {
    if (!isOpen) return undefined;

    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowLeft") {
        onNavigate((activeIndex - 1 + items.length) % items.length);
      } else if (e.key === "ArrowRight") {
        onNavigate((activeIndex + 1) % items.length);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeIndex, isOpen, items.length, onClose, onNavigate]);

  const handlePrev = () => {
    onNavigate((activeIndex - 1 + items.length) % items.length);
  };

  const handleNext = () => {
    onNavigate((activeIndex + 1) % items.length);
  };

  return (
    <AnimatePresence>
      {isOpen && activeItem && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={activeItem.caption[language] || activeItem.caption.en}
          className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#351B29]/95 p-4 text-[#FFF0E8] backdrop-blur-md sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          onClick={onClose}
        >
          {/* Top Controls */}
          <div
            className="flex w-full max-w-6xl items-center justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="text-xs font-medium tracking-widest text-[#E9BFA5] uppercase tabular-nums sm:text-sm">
              {activeIndex + 1} {t.gallery.photoCounter} {items.length}
            </span>

            <button
              type="button"
              onClick={onClose}
              aria-label={t.gallery.closeLightbox}
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-[#E9BFA5]/30 text-[#FFF0E8] transition-colors hover:border-[#FFF0E8] hover:bg-[#FFF0E8]/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5]"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Center Media Viewport */}
          <div
            className="relative flex w-full max-w-5xl flex-1 items-center justify-center py-4"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={handlePrev}
              aria-label={t.gallery.previousPhoto}
              className="mr-2 inline-flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-full border border-[#E9BFA5]/35 bg-[#351B29]/80 text-[#FFF0E8] transition-colors hover:border-[#FFF0E8] hover:bg-[#762C3A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5] sm:mr-4"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeItem.id}
                initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={prefersReducedMotion ? false : { opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.3, ease: EASE_LUXURY }}
                className="flex max-h-[70vh] w-full max-w-3xl flex-col items-center justify-center overflow-hidden rounded-xl border border-[#E9BFA5]/25 bg-[#351B29]"
              >
                {activeItem.src &&
                activeItem.src.trim() !== "" &&
                failedId !== activeItem.id ? (
                  <img
                    src={activeItem.src}
                    alt={activeItem.alt[language] || activeItem.alt.en}
                    referrerPolicy="no-referrer"
                    onError={() => setFailedId(activeItem.id)}
                    className="max-h-[65vh] w-auto max-w-full object-contain"
                  />
                ) : (
                  <div className="kolam-dark-pattern flex aspect-[4/3] w-full flex-col items-center justify-center p-8 text-center">
                    <KolamMandala className="mb-4 h-28 w-28 sm:h-36 sm:w-36" light />
                    <p className="font-serif text-2xl text-[#FFF0E8] sm:text-3xl">
                      {activeItem.caption[language] || activeItem.caption.en}
                    </p>
                    <p className="mt-2 max-w-md text-xs leading-relaxed text-[#E9BFA5]/80 sm:text-sm">
                      {t.gallery.emptyNoticeBody}
                    </p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <button
              type="button"
              onClick={handleNext}
              aria-label={t.gallery.nextPhoto}
              className="ml-2 inline-flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-full border border-[#E9BFA5]/35 bg-[#351B29]/80 text-[#FFF0E8] transition-colors hover:border-[#FFF0E8] hover:bg-[#762C3A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5] sm:ml-4"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          {/* Caption */}
          <div className="pb-2 text-center" onClick={(e) => e.stopPropagation()}>
            <p className="font-serif text-xl text-[#FFF0E8] sm:text-2xl">
              {activeItem.caption[language] || activeItem.caption.en}
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
