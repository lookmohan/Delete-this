import { motion, useReducedMotion } from "framer-motion";
import { Calendar, Clock, MapPin } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import {
  formatEventDate,
  formatTimeDisplay,
  weddingEventsList,
} from "../data/events";
import { EASE_LUXURY } from "../animations/motionVariants";
import { EventMap } from "./EventMap";

export function EventTimeline() {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="relative">
      {/* Progressive Vertical Timeline Line on Desktop/Tablet */}
      <motion.div
        aria-hidden="true"
        className="absolute top-3 bottom-6 left-4 hidden w-px origin-top bg-[#B66A54]/35 md:block"
        initial={prefersReducedMotion ? false : { scaleY: 0 }}
        whileInView={{ scaleY: 1 }}
        viewport={{ once: true, amount: 0.1 }}
        transition={{ duration: 1.2, ease: EASE_LUXURY }}
      />

      <div className="space-y-16 sm:space-y-20">
        {weddingEventsList.map((event, idx) => {
          const formattedDate = formatEventDate(event.date, language);
          const formattedTime = formatTimeDisplay(
            event.time,
            event.timeConfirmed,
            language
          );
          const venueDisplay =
            event.venue && event.venue.trim() !== ""
              ? event.venue
              : t.events.venuePending;

          return (
            <motion.article
              key={event.id}
              initial={prefersReducedMotion ? false : { opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{
                duration: 0.7,
                delay: prefersReducedMotion ? 0 : idx * 0.08,
                ease: EASE_LUXURY,
              }}
              className="relative md:pl-14"
            >
              {/* Timeline Node Marker */}
              <div
                aria-hidden="true"
                className="absolute top-2 left-0 hidden h-8 w-8 items-center justify-center rounded-full border border-[#B66A54]/50 bg-[#FFF0E8] font-serif text-xs font-semibold text-[#762C3A] md:flex"
              >
                {event.order}
              </div>

              <div className="border-b border-[#B66A54]/25 pb-14 last:border-b-0">
                <div className="grid gap-8 lg:grid-cols-12 lg:items-start lg:gap-10">
                  {/* Editorial Event Details Column */}
                  <div className="lg:col-span-5">
                    <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.2em] text-[#B66A54] uppercase">
                      <span>{event.order}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {language === "ta" ? event.title.en : event.title.ta}
                      </span>
                    </div>

                    <h2 className="mt-2 font-serif text-3xl font-semibold text-[#351B29] sm:text-4xl">
                      {event.title[language]}
                    </h2>
                    <p className="mt-1.5 text-sm leading-relaxed text-[#762C3A]/85">
                      {event.subtitle[language]}
                    </p>

                    <dl className="mt-7 space-y-4 border-t border-[#B66A54]/20 pt-6">
                      <motion.div
                        initial={prefersReducedMotion ? false : { opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.12, ease: EASE_LUXURY }}
                        className="flex items-start gap-3"
                      >
                        <Calendar className="mt-0.5 h-4 w-4 shrink-0 text-[#B66A54]" />
                        <div>
                          <dt className="text-xs font-medium tracking-wider text-[#762C3A]/75 uppercase">
                            {t.events.dateLabel}
                          </dt>
                          <dd className="mt-0.5 text-base font-medium text-[#351B29]">
                            {formattedDate}
                          </dd>
                        </div>
                      </motion.div>

                      <motion.div
                        initial={prefersReducedMotion ? false : { opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.2, ease: EASE_LUXURY }}
                        className="flex items-start gap-3"
                      >
                        <Clock className="mt-0.5 h-4 w-4 shrink-0 text-[#B66A54]" />
                        <div>
                          <dt className="text-xs font-medium tracking-wider text-[#762C3A]/75 uppercase">
                            {t.events.timeLabel}
                          </dt>
                          <dd
                            className={`mt-0.5 text-base ${
                              event.timeConfirmed
                                ? "font-semibold text-[#351B29]"
                                : "italic text-[#762C3A]/80"
                            }`}
                          >
                            {formattedTime}
                          </dd>
                        </div>
                      </motion.div>

                      <motion.div
                        initial={prefersReducedMotion ? false : { opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.28, ease: EASE_LUXURY }}
                        className="flex items-start gap-3"
                      >
                        <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#B66A54]" />
                        <div>
                          <dt className="text-xs font-medium tracking-wider text-[#762C3A]/75 uppercase">
                            {t.events.venueLabel}
                          </dt>
                          <dd
                            className={`mt-0.5 text-base ${
                              event.venue
                                ? "font-semibold text-[#351B29]"
                                : "italic text-[#762C3A]/80"
                            }`}
                          >
                            {venueDisplay}
                          </dd>
                        </div>
                      </motion.div>
                    </dl>
                  </div>

                  {/* Embedded Google Map Column */}
                  <div className="lg:col-span-7">
                    <EventMap event={event} />
                  </div>
                </div>
              </div>
            </motion.article>
          );
        })}
      </div>
    </div>
  );
}
