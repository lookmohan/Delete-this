import { useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { X } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";
import { NAV_ROUTES } from "./Navbar";
import { TempleDivider } from "./OrnamentalMotifs";

export function MobileMenu({ isOpen, onClose }) {
  const { t } = useLanguage();
  const location = useLocation();
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (!isOpen) return undefined;

    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-[#351B29]/65 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
          />

          {/* Slide-over Drawer */}
          <motion.div
            className="kolam-dark-pattern fixed inset-y-0 right-0 flex w-full max-w-xs flex-col justify-between bg-[#351B29] px-6 py-6 text-[#FFF0E8] shadow-2xl"
            initial={prefersReducedMotion ? { opacity: 0 } : { x: "100%" }}
            animate={prefersReducedMotion ? { opacity: 1 } : { x: 0 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { x: "100%" }}
            transition={{ duration: 0.38, ease: EASE_LUXURY }}
          >
            <div>
              <div className="flex items-center justify-between border-b border-[#E9BFA5]/20 pb-4">
                <span className="font-serif text-xl font-semibold text-[#FFF0E8]">
                  {t.brandShort}
                </span>
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Close navigation menu"
                  className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-[#E9BFA5]/30 text-[#E9BFA5] transition-colors hover:border-[#FFF0E8] hover:text-[#FFF0E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5]"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <nav aria-label="Mobile" className="mt-6 flex flex-col gap-1.5">
                {NAV_ROUTES.map((item, idx) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <motion.div
                      key={item.path}
                      initial={prefersReducedMotion ? false : { opacity: 0, x: 16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{
                        duration: 0.35,
                        delay: prefersReducedMotion ? 0 : 0.05 + idx * 0.045,
                        ease: EASE_LUXURY,
                      }}
                    >
                      <NavLink
                        to={item.path}
                        onClick={onClose}
                        className={`flex min-h-[48px] items-center justify-between rounded-lg px-4 text-base font-medium transition-colors ${
                          isActive
                            ? "bg-[#762C3A] text-[#FFF0E8]"
                            : "text-[#E9BFA5] hover:bg-[#FFF0E8]/10 hover:text-[#FFF0E8]"
                        }`}
                      >
                        <span>{t.nav[item.key]}</span>
                        <span className="text-xs text-[#E9BFA5]/70">
                          0{idx + 1}
                        </span>
                      </NavLink>
                    </motion.div>
                  );
                })}
              </nav>
            </div>

            <div className="pt-6 text-center">
              <TempleDivider className="my-4" light />
              <p className="font-serif text-sm text-[#E9BFA5]">
                {weddingConfig.groom.name} &amp; {weddingConfig.bride.name}
              </p>
              <p className="mt-1 text-xs tracking-widest text-[#E9BFA5]/70 uppercase">
                {t.weddingDateMain}
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
