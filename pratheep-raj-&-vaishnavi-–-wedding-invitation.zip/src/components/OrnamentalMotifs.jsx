import { motion, useReducedMotion } from "framer-motion";
import { EASE_LUXURY, kolamStrokeVariant } from "../animations/motionVariants";

export function KolamMandala({ className = "w-44 h-44", animated = false, light = false }) {
  const prefersReducedMotion = useReducedMotion();
  const shouldAnimate = animated && !prefersReducedMotion;
  const strokePrimary = light ? "#E9BFA5" : "#B66A54";
  const strokeSecondary = light ? "#B66A54" : "#762C3A";

  return (
    <svg
      viewBox="0 0 200 200"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <motion.circle
        cx="100"
        cy="100"
        r="88"
        stroke={strokePrimary}
        strokeWidth="1"
        strokeDasharray="4 4"
        variants={shouldAnimate ? kolamStrokeVariant : undefined}
        initial={shouldAnimate ? "hidden" : false}
        animate={shouldAnimate ? "visible" : undefined}
        custom={0}
      />
      <motion.circle
        cx="100"
        cy="100"
        r="74"
        stroke={strokePrimary}
        strokeWidth="1.2"
        variants={shouldAnimate ? kolamStrokeVariant : undefined}
        initial={shouldAnimate ? "hidden" : false}
        animate={shouldAnimate ? "visible" : undefined}
        custom={0.15}
      />
      {/* 8-petal lotus kolam geometry */}
      <motion.path
        d="M100 22 C112 52 148 88 178 100 C148 112 112 148 100 178 C88 148 52 112 22 100 C52 88 88 52 100 22 Z"
        stroke={strokePrimary}
        strokeWidth="1.25"
        variants={shouldAnimate ? kolamStrokeVariant : undefined}
        initial={shouldAnimate ? "hidden" : false}
        animate={shouldAnimate ? "visible" : undefined}
        custom={0.25}
      />
      <motion.path
        d="M45 45 C75 62 125 62 155 45 C138 75 138 125 155 155 C125 138 75 138 45 155 C62 125 62 75 45 45 Z"
        stroke={strokeSecondary}
        strokeWidth="1.15"
        variants={shouldAnimate ? kolamStrokeVariant : undefined}
        initial={shouldAnimate ? "hidden" : false}
        animate={shouldAnimate ? "visible" : undefined}
        custom={0.45}
      />
      <motion.circle
        cx="100"
        cy="100"
        r="24"
        stroke={strokePrimary}
        strokeWidth="1.2"
        variants={shouldAnimate ? kolamStrokeVariant : undefined}
        initial={shouldAnimate ? "hidden" : false}
        animate={shouldAnimate ? "visible" : undefined}
        custom={0.6}
      />
      <circle cx="100" cy="100" r="4" fill={strokeSecondary} />
      <circle cx="100" cy="14" r="2.2" fill={strokePrimary} />
      <circle cx="100" cy="186" r="2.2" fill={strokePrimary} />
      <circle cx="14" cy="100" r="2.2" fill={strokePrimary} />
      <circle cx="186" cy="100" r="2.2" fill={strokePrimary} />
    </svg>
  );
}

export function TempleDivider({ className = "my-8", light = false }) {
  const prefersReducedMotion = useReducedMotion();
  const lineColor = light ? "bg-[#E9BFA5]/35" : "bg-[#B66A54]/30";
  const accentColor = light ? "#E9BFA5" : "#762C3A";

  return (
    <div className={`flex items-center justify-center gap-4 ${className}`} aria-hidden="true">
      <motion.div
        className={`h-px flex-1 max-w-[140px] origin-right ${lineColor}`}
        initial={prefersReducedMotion ? false : { scaleX: 0, opacity: 0 }}
        whileInView={{ scaleX: 1, opacity: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.8, ease: EASE_LUXURY }}
      />
      <svg width="36" height="20" viewBox="0 0 36 20" fill="none">
        <path
          d="M18 2 C20.5 7 25 9.5 32 10 C25 10.5 20.5 13 18 18 C15.5 13 11 10.5 4 10 C11 9.5 15.5 7 18 2 Z"
          stroke={accentColor}
          strokeWidth="1.2"
        />
        <circle cx="18" cy="10" r="2" fill="#B66A54" />
      </svg>
      <motion.div
        className={`h-px flex-1 max-w-[140px] origin-left ${lineColor}`}
        initial={prefersReducedMotion ? false : { scaleX: 0, opacity: 0 }}
        whileInView={{ scaleX: 1, opacity: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.8, ease: EASE_LUXURY }}
      />
    </div>
  );
}

export function JasminePetalsLayer({ count = 10, light = true }) {
  const prefersReducedMotion = useReducedMotion();
  if (prefersReducedMotion) return null;

  const petals = Array.from({ length: count }, (_, idx) => ({
    id: idx,
    left: `${8 + ((idx * 19) % 84)}%`,
    delay: (idx % 5) * 0.85,
    duration: 7.5 + (idx % 4) * 1.4,
    size: 10 + (idx % 3) * 4,
    drift: idx % 2 === 0 ? 22 : -22,
  }));

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {petals.map((petal) => (
        <motion.div
          key={petal.id}
          className="absolute -top-6"
          style={{ left: petal.left }}
          initial={{ y: -20, x: 0, opacity: 0, rotate: 0 }}
          animate={{
            y: ["0vh", "105vh"],
            x: [0, petal.drift, -petal.drift * 0.5],
            opacity: [0, 0.72, 0.65, 0],
            rotate: [0, 140, 260],
          }}
          transition={{
            duration: petal.duration,
            delay: petal.delay,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <svg
            width={petal.size}
            height={petal.size * 1.4}
            viewBox="0 0 14 20"
            fill="none"
          >
            <path
              d="M7 1 C11 5 13 11 7 19 C1 11 3 5 7 1 Z"
              fill={light ? "#FFF0E8" : "#E9BFA5"}
              fillOpacity={light ? "0.6" : "0.55"}
            />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}
