import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Expand } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { EASE_LUXURY } from "../animations/motionVariants";
import { KolamMandala } from "./OrnamentalMotifs";

export function GalleryCard({ item, index, onOpen }) {
  const { language, t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  const [failed, setFailed] = useState(false);

  const hasValidSrc = Boolean(item.src && item.src.trim() !== "" && !failed);
  const caption = item.caption[language] || item.caption.en;
  const alt = item.alt[language] || item.alt.en;

  return (
    <motion.button
      type="button"
      onClick={() => onOpen(index)}
      initial={prefersReducedMotion ? false : { opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{
        duration: 0.6,
        delay: prefersReducedMotion ? 0 : (index % 3) * 0.08,
        ease: EASE_LUXURY,
      }}
      className="group relative flex w-full flex-col overflow-hidden rounded-xl border border-[#B66A54]/25 bg-[#FFF0E8] text-left transition-colors hover:border-[#762C3A]/50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A]"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#351B29]">
        {hasValidSrc ? (
          <img
            src={item.src}
            alt={alt}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setFailed(true)}
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
        ) : (
          <div className="kolam-dark-pattern relative flex h-full w-full flex-col items-center justify-center p-6 text-center text-[#FFF0E8] transition-transform duration-700 ease-out group-hover:scale-[1.03]">
            <div className="pointer-events-none absolute inset-3 rounded-lg border border-[#E9BFA5]/20" />
            <KolamMandala className="mb-3 h-20 w-20 opacity-85" light />
            <span className="text-[11px] font-medium tracking-[0.2em] text-[#E9BFA5]/80 uppercase">
              {t.gallery.placeholderPlate} · 0{index + 1}
            </span>
          </div>
        )}

        <div
          aria-hidden="true"
          className="absolute right-3 bottom-3 flex h-9 w-9 items-center justify-center rounded-lg bg-[#351B29]/80 text-[#FFF0E8] opacity-0 backdrop-blur-sm transition-opacity duration-200 group-hover:opacity-100"
        >
          <Expand className="h-4 w-4" />
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 px-4 py-3.5">
        <span className="font-serif text-lg font-medium text-[#351B29]">
          {caption}
        </span>
        <span className="text-xs font-medium text-[#762C3A]/70 tabular-nums">
          0{index + 1}
        </span>
      </div>
    </motion.button>
  );
}

export function GalleryGrid({ items, onSelect }) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((item, idx) => (
        <GalleryCard key={item.id} item={item} index={idx} onOpen={onSelect} />
      ))}
    </div>
  );
}
