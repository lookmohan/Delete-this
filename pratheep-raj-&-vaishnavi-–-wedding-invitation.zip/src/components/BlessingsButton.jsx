import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Check, Heart, Loader2, RotateCcw } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { EASE_LUXURY } from "../animations/motionVariants";

export function BlessingsButton({ senderName = "", customMessage = "" }) {
  const { t } = useLanguage();
  const prefersReducedMotion = useReducedMotion();
  // states: "idle" | "processing" | "whatsapp" | "shared" | "copied"
  const [status, setStatus] = useState("idle");

  const buildShareText = () => {
    const trimmedMsg = customMessage.trim();
    const trimmedName = senderName.trim();
    const baseText = trimmedMsg || t.wishes.defaultShareText;
    const signature = trimmedName ? `\n— ${trimmedName}` : "";
    return `${baseText}${signature}`;
  };

  const getInvitationUrl = () => {
    if (weddingConfig.invitationUrl && weddingConfig.invitationUrl.trim() !== "") {
      return weddingConfig.invitationUrl.trim();
    }
    return window.location.origin;
  };

  const copyToClipboard = async (text) => {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
  };

  const handleClick = async () => {
    if (status === "processing") return;
    setStatus("processing");

    // Brief tactile processing beat for smooth feedback
    await new Promise((resolve) => window.setTimeout(resolve, 480));

    const shareUrl = getInvitationUrl();
    const shareBody = buildShareText();
    const cleanPhone = (weddingConfig.whatsappNumber || "").replace(/[^\d]/g, "");

    // 1. WhatsApp path when family WhatsApp number is configured
    if (cleanPhone.length > 0) {
      const fullWhatsappText = `${shareBody}\n\n${shareUrl}`;
      const waHref = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(
        fullWhatsappText
      )}`;
      const link = document.createElement("a");
      link.href = waHref;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setStatus("whatsapp");
      return;
    }

    // 2. Native Web Share API when available
    if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
      try {
        await navigator.share({
          title: t.brandShort,
          text: shareBody,
          url: shareUrl,
        });
        setStatus("shared");
        return;
      } catch (err) {
        if (err && err.name === "AbortError") {
          setStatus("idle");
          return;
        }
        // Fall through to clipboard copy if share fails for non-abort reasons
      }
    }

    // 3. Copy Invitation Link fallback
    try {
      await copyToClipboard(`${shareBody}\n${shareUrl}`);
    } catch {
      // Even if clipboard permissions are blocked in sandbox, still show clear status
    }
    setStatus("copied");
  };

  const isDone = status === "whatsapp" || status === "shared" || status === "copied";

  const statusHeadline =
    status === "whatsapp"
      ? t.wishes.statusWhatsappReady
      : status === "shared"
      ? t.wishes.statusShareReady
      : status === "copied"
      ? t.wishes.statusCopied
      : "";

  const statusHelper =
    status === "whatsapp"
      ? t.wishes.helperWhatsapp
      : status === "shared"
      ? t.wishes.helperShare
      : status === "copied"
      ? t.wishes.helperCopied
      : "";

  return (
    <div className="relative flex flex-col items-center">
      {/* Subtle celebratory jasmine/heart burst on ready state */}
      <AnimatePresence>
        {isDone && !prefersReducedMotion && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2"
          >
            {[-44, -22, 0, 22, 44].map((offset, idx) => (
              <motion.span
                key={offset}
                initial={{ opacity: 0, y: 10, x: 0, scale: 0.6 }}
                animate={{
                  opacity: [0, 1, 0],
                  y: [-4, -36 - (idx % 2) * 14],
                  x: [0, offset],
                  scale: [0.6, 1, 0.8],
                }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.15, delay: idx * 0.06, ease: EASE_LUXURY }}
                className="absolute"
              >
                <Heart className="h-3.5 w-3.5 fill-[#B66A54] text-[#B66A54]" />
              </motion.span>
            ))}
          </div>
        )}
      </AnimatePresence>

      <motion.button
        type="button"
        disabled={status === "processing"}
        onClick={handleClick}
        whileHover={status === "processing" ? undefined : { scale: 1.03 }}
        whileTap={status === "processing" ? undefined : { scale: 0.97 }}
        transition={{ duration: 0.2, ease: EASE_LUXURY }}
        aria-live="polite"
        className={`relative inline-flex min-h-[52px] min-w-[240px] items-center justify-center gap-3 rounded-xl px-8 py-3.5 text-base font-semibold shadow-md transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#762C3A] ${
          status === "processing"
            ? "cursor-wait bg-[#762C3A]/85 text-[#E9BFA5]"
            : isDone
            ? "bg-[#351B29] text-[#FFF0E8]"
            : "bg-[#762C3A] text-[#FFF0E8] hover:bg-[#8B3545]"
        }`}
      >
        <AnimatePresence mode="wait" initial={false}>
          {status === "idle" && (
            <motion.span
              key="idle"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="inline-flex items-center gap-2.5"
            >
              <Heart className="h-4 w-4 text-[#E9BFA5]" />
              <span>{t.wishes.buttonIdle}</span>
            </motion.span>
          )}

          {status === "processing" && (
            <motion.span
              key="processing"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="inline-flex items-center gap-2.5"
            >
              <Loader2 className="h-4 w-4 animate-spin text-[#E9BFA5]" />
              <span>{t.wishes.buttonProcessing}</span>
            </motion.span>
          )}

          {isDone && (
            <motion.span
              key="done"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.25, ease: EASE_LUXURY }}
              className="inline-flex items-center gap-2.5"
            >
              <Check className="h-5 w-5 text-[#E9BFA5]" />
              <span>{statusHeadline}</span>
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {isDone && (
          <motion.div
            role="status"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.35, ease: EASE_LUXURY }}
            className="mt-5 flex flex-col items-center text-center"
          >
            <p className="max-w-md text-sm leading-relaxed text-[#351B29]/85">
              {statusHelper}
            </p>
            <button
              type="button"
              onClick={() => setStatus("idle")}
              className="mt-3 inline-flex min-h-[40px] items-center gap-1.5 text-xs font-semibold tracking-wider text-[#762C3A] uppercase transition-colors hover:text-[#351B29]"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>{t.wishes.sendAnother}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
