import { Link } from "react-router-dom";
import { RotateCcw } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { weddingConfig } from "../data/weddingConfig";
import { NAV_ROUTES } from "./Navbar";
import { TempleDivider } from "./OrnamentalMotifs";

export function Footer({ onReplayIntro }) {
  const { t } = useLanguage();

  return (
    <footer className="kolam-dark-pattern border-t border-[#E9BFA5]/20 bg-[#351B29] pt-14 pb-24 text-[#FFF0E8] md:pb-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-3 md:items-start">
          {/* Couple & Blessings */}
          <div>
            <p className="text-xs font-medium tracking-[0.2em] text-[#E9BFA5] uppercase">
              {t.footer.blessingsLine}
            </p>
            <h2 className="mt-2 font-serif text-2xl font-semibold text-[#FFF0E8] sm:text-3xl">
              {weddingConfig.groom.name} &amp; {weddingConfig.bride.name}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-[#E9BFA5]/85">
              {t.footer.groomParents}
              <span className="mx-2 text-[#B66A54]">·</span>
              {t.footer.brideParents}
            </p>
          </div>

          {/* Navigation Links */}
          <div>
            <h3 className="text-xs font-semibold tracking-[0.18em] text-[#E9BFA5] uppercase">
              {t.footer.navigateTitle}
            </h3>
            <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2.5">
              {NAV_ROUTES.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className="inline-flex min-h-[36px] items-center text-sm text-[#FFF0E8]/85 transition-colors hover:text-[#E9BFA5]"
                  >
                    {t.nav[item.key]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Replay Intro & Audio Customization Note */}
          <div className="flex flex-col items-start md:items-end">
            {onReplayIntro && (
              <button
                type="button"
                onClick={onReplayIntro}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-[#E9BFA5]/35 px-4 py-2 text-sm font-medium text-[#E9BFA5] transition-colors hover:border-[#FFF0E8] hover:text-[#FFF0E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E9BFA5]"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{t.intro.replayIntro}</span>
              </button>
            )}
            <p className="mt-4 text-xs text-[#E9BFA5]/70 md:text-right">
              {t.footer.musicNote}
            </p>
          </div>
        </div>

        <TempleDivider className="my-8" light />

        <div className="flex flex-col items-center justify-between gap-2 text-center text-xs text-[#E9BFA5]/75 sm:flex-row sm:text-left">
          <p>{t.footer.copyright}</p>
          <p>{t.weddingLabel}</p>
        </div>
      </div>
    </footer>
  );
}
