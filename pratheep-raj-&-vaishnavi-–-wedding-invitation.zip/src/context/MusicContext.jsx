import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { weddingConfig } from "../data/weddingConfig";

const MusicContext = createContext(null);

export function MusicProvider({ children }) {
  const audioRef = useRef(null);
  const fadeFrameRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUnavailable, setIsUnavailable] = useState(false);
  const [showUnavailableNotice, setShowUnavailableNotice] = useState(false);

  const clearFade = useCallback(() => {
    if (fadeFrameRef.current) {
      window.cancelAnimationFrame(fadeFrameRef.current);
      fadeFrameRef.current = null;
    }
  }, []);

  useEffect(() => {
    const audio = new Audio(weddingConfig.audio);
    audio.loop = true;
    audio.preload = "none";
    audio.volume = 0;

    const handleError = () => {
      setIsUnavailable(true);
      setIsPlaying(false);
    };

    const handleEnded = () => {
      setIsPlaying(false);
    };

    audio.addEventListener("error", handleError);
    audio.addEventListener("ended", handleEnded);
    audioRef.current = audio;

    return () => {
      clearFade();
      audio.removeEventListener("error", handleError);
      audio.removeEventListener("ended", handleEnded);
      audio.pause();
      audioRef.current = null;
    };
  }, [clearFade]);

  const fadeVolume = useCallback(
    (targetVolume, durationMs, onFinish) => {
      const audio = audioRef.current;
      if (!audio) return;
      clearFade();

      const startVolume = audio.volume;
      const startTime = performance.now();

      const step = (now) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / durationMs, 1);
        audio.volume = Math.max(
          0,
          Math.min(1, startVolume + (targetVolume - startVolume) * progress)
        );
        if (progress < 1) {
          fadeFrameRef.current = window.requestAnimationFrame(step);
        } else {
          fadeFrameRef.current = null;
          if (onFinish) onFinish();
        }
      };

      fadeFrameRef.current = window.requestAnimationFrame(step);
    },
    [clearFade]
  );

  const togglePlay = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isUnavailable) {
      setShowUnavailableNotice(true);
      window.setTimeout(() => setShowUnavailableNotice(false), 4500);
      return;
    }

    if (isPlaying) {
      setIsPlaying(false);
      fadeVolume(0, 350, () => {
        audio.pause();
      });
      return;
    }

    try {
      audio.volume = 0;
      await audio.play();
      setIsPlaying(true);
      fadeVolume(0.55, 650);
    } catch {
      setIsUnavailable(true);
      setIsPlaying(false);
      setShowUnavailableNotice(true);
      window.setTimeout(() => setShowUnavailableNotice(false), 4500);
    }
  }, [fadeVolume, isPlaying, isUnavailable]);

  return (
    <MusicContext.Provider
      value={{
        isPlaying,
        isUnavailable,
        showUnavailableNotice,
        dismissNotice: () => setShowUnavailableNotice(false),
        togglePlay,
      }}
    >
      {children}
    </MusicContext.Provider>
  );
}

export function useMusic() {
  const ctx = useContext(MusicContext);
  if (!ctx) {
    throw new Error("useMusic must be used within a MusicProvider");
  }
  return ctx;
}
