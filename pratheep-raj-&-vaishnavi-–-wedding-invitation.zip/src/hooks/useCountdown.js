import { useEffect, useState } from "react";
import { weddingConfig } from "../data/weddingConfig";

function getTargetTimestamp() {
  const { date, time, useDateOnlyUntilTimeConfirmed } = weddingConfig.countdown;
  const effectiveTime =
    time && time.trim() !== ""
      ? time.trim()
      : useDateOnlyUntilTimeConfirmed
      ? "00:00"
      : "00:00";

  // Asia/Kolkata is fixed at UTC+05:30 (no DST)
  const isoString = `${date}T${effectiveTime}:00+05:30`;
  const parsed = Date.parse(isoString);
  return Number.isNaN(parsed) ? Date.parse("2027-04-23T00:00:00+05:30") : parsed;
}

function calculateRemaining(targetMs) {
  const now = Date.now();
  const diff = targetMs - now;

  if (diff <= 0) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      isCompleted: true,
    };
  }

  const totalSeconds = Math.floor(diff / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return {
    days,
    hours,
    minutes,
    seconds,
    isCompleted: false,
  };
}

export function useCountdown() {
  const targetMs = getTargetTimestamp();
  const [timeLeft, setTimeLeft] = useState(() => calculateRemaining(targetMs));

  useEffect(() => {
    setTimeLeft(calculateRemaining(targetMs));
    const intervalId = window.setInterval(() => {
      setTimeLeft(calculateRemaining(targetMs));
    }, 1000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [targetMs]);

  return timeLeft;
}
